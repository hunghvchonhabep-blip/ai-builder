import { jsonb, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

export type SiteFile = { path: string; content: string };

export const sitesTable = pgTable("sites", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  prompt: text("prompt").notNull(),
  html: text("html").notNull(),
  format: text("format").notNull().default("html"),
  files: jsonb("files").$type<SiteFile[]>().notNull().default([]),
  industry: text("industry"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Site = typeof sitesTable.$inferSelect;
export type InsertSite = typeof sitesTable.$inferInsert;
