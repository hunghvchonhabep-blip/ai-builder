import { integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

export const commissionsTable = pgTable("commissions", {
  id: uuid("id").primaryKey().defaultRandom(),
  affiliateUserId: uuid("affiliate_user_id").notNull(),
  sourceUserId: uuid("source_user_id").notNull(),
  sourceTopupId: uuid("source_topup_id"),
  amountVnd: integer("amount_vnd").notNull(),
  status: text("status").notNull().default("pending"),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
});

export type Commission = typeof commissionsTable.$inferSelect;
export type InsertCommission = typeof commissionsTable.$inferInsert;
