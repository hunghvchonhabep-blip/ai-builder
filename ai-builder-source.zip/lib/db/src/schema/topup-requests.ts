import { integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

export const topupRequestsTable = pgTable("topup_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  amountVnd: integer("amount_vnd").notNull(),
  points: integer("points").notNull(),
  method: text("method").notNull(),
  status: text("status").notNull().default("pending"),
  proofNote: text("proof_note"),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  processedAt: timestamp("processed_at", { withTimezone: true }),
});

export type TopupRequest = typeof topupRequestsTable.$inferSelect;
export type InsertTopupRequest = typeof topupRequestsTable.$inferInsert;
