import { integer, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";

export const pointTransactionsTable = pgTable("point_transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  delta: integer("delta").notNull(),
  reason: text("reason").notNull(),
  siteId: uuid("site_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type PointTransaction = typeof pointTransactionsTable.$inferSelect;
export type InsertPointTransaction = typeof pointTransactionsTable.$inferInsert;
