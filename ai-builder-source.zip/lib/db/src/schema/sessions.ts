import { json, pgTable, text, timestamp } from "drizzle-orm/pg-core";

// Used by connect-pg-simple. Schema is fixed by that library.
export const sessionsTable = pgTable("session", {
  sid: text("sid").primaryKey(),
  sess: json("sess").notNull(),
  expire: timestamp("expire", { mode: "date", precision: 6 }).notNull(),
});
