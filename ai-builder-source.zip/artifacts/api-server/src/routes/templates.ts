import { Router, type IRouter } from "express";

const router: IRouter = Router();

type TemplateMeta = {
  id: string;
  title: string;
  description: string;
  prompt: string;
  industry: string;
  emoji: string;
  accentColor: string;
  brandName: string;
  tagline: string;
  cta: string;
  features: { title: string; body: string }[];
  heroImage: string;
};

const TEMPLATES_META: TemplateMeta[] = [
  {
    id: "coffee-shop",
    title: "Quán cà phê specialty",
    description: "Landing page ấm cúng cho quán cà phê thủ công",
    prompt:
      "Trang web cho quán cà phê specialty tên 'Mộc Coffee' ở Đà Lạt, không gian gỗ ấm áp, rang xay tại chỗ, có menu pour-over, espresso, và workshop barista cuối tuần.",
    industry: "restaurant",
    emoji: "☕",
    accentColor: "#8B5E3C",
    brandName: "Mộc Coffee",
    tagline: "Cà phê thủ công, rang xay mỗi sáng tại Đà Lạt",
    cta: "Đặt bàn ngay",
    features: [
      { title: "Pour-over", body: "Single origin từ Cầu Đất, A Lưới, Sơn La." },
      { title: "Workshop", body: "Lớp barista cuối tuần cho người mới bắt đầu." },
      { title: "Không gian gỗ", body: "Yên tĩnh, ấm áp, view rừng thông." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=1200&q=80",
  },
  {
    id: "saas-startup",
    title: "Khởi nghiệp SaaS",
    description: "Trang giới thiệu sản phẩm phần mềm B2B hiện đại",
    prompt:
      "A landing page for 'FlowDesk', a project management SaaS for remote design teams. Clean, modern, with clear feature breakdown, pricing tiers, and customer logos.",
    industry: "saas",
    emoji: "💻",
    accentColor: "#6366F1",
    brandName: "FlowDesk",
    tagline: "Project management built for remote design teams",
    cta: "Start free trial",
    features: [
      { title: "Visual roadmaps", body: "See sprints, releases, and reviews on one timeline." },
      { title: "Real-time canvas", body: "Annotate Figma files without leaving the task." },
      { title: "Async standups", body: "Loom + checklist in one daily digest." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1551434678-e076c223a692?w=1200&q=80",
  },
  {
    id: "fashion-brand",
    title: "Thương hiệu thời trang",
    description: "Lookbook cho thương hiệu local, nét tối giản",
    prompt:
      "Trang web cho thương hiệu thời trang local Việt Nam tên 'Nâu Studio', phong cách tối giản, chất liệu linen và cotton, hướng tới phụ nữ 25-35 tuổi yêu thiên nhiên.",
    industry: "fashion",
    emoji: "👗",
    accentColor: "#A47551",
    brandName: "Nâu Studio",
    tagline: "Linen, cotton, và những điều giản dị",
    cta: "Khám phá BST",
    features: [
      { title: "Chất liệu tự nhiên", body: "Linen Bỉ, cotton hữu cơ, nhuộm thực vật." },
      { title: "Cắt may slow-fashion", body: "Mỗi mẫu chỉ sản xuất giới hạn 30 chiếc." },
      { title: "Made in Hội An", body: "Hợp tác với xưởng may gia đình ba thế hệ." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&q=80",
  },
  {
    id: "yoga-studio",
    title: "Studio Yoga",
    description: "Trang đặt lịch lớp học cho studio yoga",
    prompt:
      "Trang web cho studio yoga 'Hơi Thở' tại Quận 2, TP.HCM. Có lịch lớp Hatha, Vinyasa, Yin, profile các giáo viên, và form đăng ký lớp thử miễn phí.",
    industry: "fitness",
    emoji: "🧘",
    accentColor: "#0F766E",
    brandName: "Hơi Thở Yoga",
    tagline: "Tìm lại nhịp thở giữa Sài Gòn",
    cta: "Đặt lớp thử miễn phí",
    features: [
      { title: "Hatha & Vinyasa", body: "Lớp sáng 6h, trưa 12h, tối 18h và 19h30." },
      { title: "Yin & Restorative", body: "Buổi tối thứ 3 và thứ 6, dành cho người căng thẳng." },
      { title: "Giáo viên RYT-500", body: "5 giáo viên chứng chỉ quốc tế Yoga Alliance." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=1200&q=80",
  },
  {
    id: "freelance-portfolio",
    title: "Portfolio freelancer",
    description: "Hồ sơ năng lực cho nhà thiết kế độc lập",
    prompt:
      "A personal portfolio for 'Linh Pham', an independent UI/UX designer based in Hanoi. Showcase 6 projects, services, testimonials, and a contact form.",
    industry: "agency",
    emoji: "🎨",
    accentColor: "#DC2626",
    brandName: "Linh Pham",
    tagline: "Independent UI/UX designer based in Hanoi",
    cta: "Start a project",
    features: [
      { title: "Product design", body: "End-to-end product flows for early stage startups." },
      { title: "Design systems", body: "Scalable component libraries built for Figma + code." },
      { title: "Brand identity", body: "Logos, type, and voice for distinctive teams." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1561070791-2526d30994b8?w=1200&q=80",
  },
  {
    id: "restaurant",
    title: "Nhà hàng fine dining",
    description: "Landing đặt bàn cho nhà hàng cao cấp",
    prompt:
      "Trang web cho nhà hàng fine dining 'Bếp Việt' tại Hội An, ẩm thực Việt hiện đại theo mùa, đầu bếp từng làm việc tại Michelin star, có thực đơn tasting menu và đặt bàn online.",
    industry: "restaurant",
    emoji: "🍽️",
    accentColor: "#7C2D12",
    brandName: "Bếp Việt",
    tagline: "Ẩm thực Việt hiện đại theo mùa, ngay tại Hội An",
    cta: "Đặt bàn",
    features: [
      { title: "Tasting menu 9 món", body: "Thay đổi theo mùa, lấy cảm hứng từ chợ Hội An." },
      { title: "Đầu bếp từ Michelin", body: "Bếp trưởng từng làm tại 1-star ở Singapore." },
      { title: "Pairing rượu thủ công", body: "Đề xuất rượu vang & sake cho từng món." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1200&q=80",
  },
  {
    id: "online-course",
    title: "Khoá học online",
    description: "Sales page cho khoá học trực tuyến",
    prompt:
      "Trang web cho khoá học online 'Tiếng Anh Giao Tiếp 30 Ngày' của trung tâm EnglishUp, target người đi làm 22-35 tuổi, có lộ trình rõ ràng, học phí, và testimonial học viên.",
    industry: "education",
    emoji: "📚",
    accentColor: "#2563EB",
    brandName: "EnglishUp",
    tagline: "Tiếng Anh giao tiếp tự tin sau 30 ngày",
    cta: "Đăng ký ngay",
    features: [
      { title: "Lộ trình 30 ngày", body: "Mỗi ngày 20 phút, có audio và bài tập tương tác." },
      { title: "Coach 1-1", body: "1 buổi nói chuyện với native speaker mỗi tuần." },
      { title: "Cộng đồng 5,000+", body: "Group thực hành hằng ngày, sự kiện offline tháng." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=1200&q=80",
  },
  {
    id: "real-estate",
    title: "Bất động sản",
    description: "Landing dự án căn hộ cao cấp",
    prompt:
      "Landing page giới thiệu dự án căn hộ cao cấp 'Riverside Residence' tại Quận 7, TP.HCM. View sông Sài Gòn, tiện ích nội khu đầy đủ, giá từ 4 tỷ, có form đăng ký nhận bảng giá.",
    industry: "real-estate",
    emoji: "🏢",
    accentColor: "#0E7490",
    brandName: "Riverside Residence",
    tagline: "Sống chậm bên sông Sài Gòn, ngay giữa Quận 7",
    cta: "Nhận bảng giá",
    features: [
      { title: "View sông trọn căn", body: "92% căn hộ sở hữu tầm nhìn trực diện sông." },
      { title: "Tiện ích nội khu", body: "Hồ bơi tràn bờ, gym, spa, trường mầm non." },
      { title: "Giá từ 4 tỷ", body: "Ngân hàng hỗ trợ vay 70%, ân hạn gốc 24 tháng." },
    ],
    heroImage:
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&q=80",
  },
];

function buildPreviewHtml(t: TemplateMeta): string {
  const featuresHtml = t.features
    .map(
      (f) => `
      <div class="p-6 rounded-2xl bg-white/70 backdrop-blur border border-black/5">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center mb-4" style="background:${t.accentColor}1A;color:${t.accentColor}">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
        </div>
        <h3 class="font-semibold text-lg mb-2 text-slate-900">${f.title}</h3>
        <p class="text-sm leading-relaxed text-slate-600">${f.body}</p>
      </div>`,
    )
    .join("");

  return `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${t.brandName}</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
<style>
  body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; }
  .display { font-family: 'Playfair Display', serif; }
  .accent-bg { background:${t.accentColor}; }
  .accent-text { color:${t.accentColor}; }
  .accent-soft { background:${t.accentColor}14; }
</style>
</head>
<body class="bg-slate-50 text-slate-900 antialiased">
  <header class="absolute inset-x-0 top-0 z-20">
    <nav class="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
      <div class="flex items-center gap-2 font-bold text-lg text-white drop-shadow">
        <span class="w-9 h-9 rounded-xl flex items-center justify-center text-white" style="background:${t.accentColor}">${t.emoji}</span>
        ${t.brandName}
      </div>
      <div class="hidden sm:flex items-center gap-6 text-sm font-medium text-white/90">
        <a href="#" class="hover:text-white">Giới thiệu</a>
        <a href="#" class="hover:text-white">Dịch vụ</a>
        <a href="#" class="hover:text-white">Liên hệ</a>
      </div>
    </nav>
  </header>

  <section class="relative overflow-hidden">
    <div class="absolute inset-0">
      <img src="${t.heroImage}" alt="" class="w-full h-full object-cover" />
      <div class="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70"></div>
    </div>
    <div class="relative max-w-6xl mx-auto px-6 pt-40 pb-32 text-white">
      <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold backdrop-blur bg-white/15 border border-white/20 uppercase tracking-wider">
        ${t.industry}
      </span>
      <h1 class="display mt-6 text-5xl sm:text-6xl font-bold leading-tight max-w-3xl">${t.tagline}</h1>
      <p class="mt-6 max-w-xl text-lg text-white/85 leading-relaxed">
        ${t.description} Ý tưởng đầu vào: "${t.prompt.length > 140 ? t.prompt.slice(0, 140) + "…" : t.prompt}"
      </p>
      <div class="mt-10 flex flex-wrap items-center gap-4">
        <a href="#" class="inline-flex items-center gap-2 px-6 py-3 rounded-full font-semibold accent-bg hover:opacity-90 transition shadow-lg">
          ${t.cta}
          <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 10a1 1 0 011-1h10.586L11.293 5.707a1 1 0 011.414-1.414l5 5a1 1 0 010 1.414l-5 5a1 1 0 01-1.414-1.414L14.586 11H4a1 1 0 01-1-1z" clip-rule="evenodd"/></svg>
        </a>
        <a href="#" class="inline-flex items-center gap-2 px-6 py-3 rounded-full font-semibold bg-white/15 backdrop-blur border border-white/30 hover:bg-white/25 transition">Tìm hiểu thêm</a>
      </div>
    </div>
  </section>

  <section class="max-w-6xl mx-auto px-6 -mt-16 relative z-10">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
      ${featuresHtml}
    </div>
  </section>

  <section class="max-w-6xl mx-auto px-6 py-24">
    <div class="rounded-3xl accent-soft p-10 sm:p-16 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-8">
      <div class="max-w-xl">
        <h2 class="display text-3xl sm:text-4xl font-bold accent-text">Sẵn sàng bắt đầu?</h2>
        <p class="mt-3 text-slate-700 leading-relaxed">Đây là bản xem trước. Khi bạn dùng mẫu này, AI sẽ sinh ra một website đầy đủ, có nội dung chi tiết và phong cách phù hợp với ý tưởng của bạn.</p>
      </div>
      <a href="#" class="inline-flex items-center gap-2 px-6 py-3 rounded-full font-semibold text-white accent-bg shadow-lg hover:opacity-90 transition whitespace-nowrap">
        ${t.cta}
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 10a1 1 0 011-1h10.586L11.293 5.707a1 1 0 011.414-1.414l5 5a1 1 0 010 1.414l-5 5a1 1 0 01-1.414-1.414L14.586 11H4a1 1 0 01-1-1z" clip-rule="evenodd"/></svg>
      </a>
    </div>
  </section>

  <footer class="border-t border-slate-200">
    <div class="max-w-6xl mx-auto px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-slate-500">
      <div>© ${new Date().getFullYear()} ${t.brandName}. Mẫu xem trước.</div>
      <div class="flex gap-5"><a href="#">Điều khoản</a><a href="#">Bảo mật</a><a href="#">Liên hệ</a></div>
    </div>
  </footer>
</body>
</html>`;
}

const TEMPLATES = TEMPLATES_META.map((t) => ({
  id: t.id,
  title: t.title,
  description: t.description,
  prompt: t.prompt,
  industry: t.industry,
  emoji: t.emoji,
  accentColor: t.accentColor,
  previewHtml: buildPreviewHtml(t),
}));

router.get("/templates", (_req, res) => {
  res.json(TEMPLATES);
});

export default router;
