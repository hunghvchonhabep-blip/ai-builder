import { Router, type IRouter } from "express";
import {
  db,
  usersTable,
  pointTransactionsTable,
  topupRequestsTable,
  commissionsTable,
} from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { CreateTopupBody } from "@workspace/api-zod";
import { wrap } from "../lib/wrap";
import { requireAuth } from "../middlewares/auth";
import {
  PRICING_TIERS,
  SIGNUP_BONUS,
  GENERATE_COST,
  REFINE_COST,
  COMMISSION_RATE_PCT,
  pointsForAmount,
} from "../lib/pricing";

const router: IRouter = Router();

router.get("/account/pricing", (_req, res) => {
  res.json({
    signupBonus: SIGNUP_BONUS,
    generateCost: GENERATE_COST,
    refineCost: REFINE_COST,
    commissionRatePct: COMMISSION_RATE_PCT,
    tiers: PRICING_TIERS,
  });
});

router.get(
  "/account/transactions",
  requireAuth,
  wrap(async (req, res) => {
    const userId = req.currentUser!.id;
    const rows = await db
      .select()
      .from(pointTransactionsTable)
      .where(eq(pointTransactionsTable.userId, userId))
      .orderBy(desc(pointTransactionsTable.createdAt))
      .limit(100);
    res.json(
      rows.map((r) => ({
        id: r.id,
        delta: r.delta,
        reason: r.reason,
        siteId: r.siteId,
        createdAt: r.createdAt.toISOString(),
      })),
    );
  }),
);

router.get(
  "/account/topups",
  requireAuth,
  wrap(async (req, res) => {
    const userId = req.currentUser!.id;
    const rows = await db
      .select()
      .from(topupRequestsTable)
      .where(eq(topupRequestsTable.userId, userId))
      .orderBy(desc(topupRequestsTable.createdAt));
    res.json(
      rows.map((r) => ({
        id: r.id,
        amountVnd: r.amountVnd,
        points: r.points,
        method: r.method,
        status: r.status,
        proofNote: r.proofNote,
        adminNote: r.adminNote,
        createdAt: r.createdAt.toISOString(),
        processedAt: r.processedAt ? r.processedAt.toISOString() : null,
      })),
    );
  }),
);

router.post(
  "/account/topups",
  requireAuth,
  wrap(async (req, res) => {
    const body = CreateTopupBody.parse(req.body);
    const userId = req.currentUser!.id;
    const points = pointsForAmount(body.amountVnd);
    const [row] = await db
      .insert(topupRequestsTable)
      .values({
        userId,
        amountVnd: body.amountVnd,
        points,
        method: body.method,
        proofNote: body.proofNote ?? null,
      })
      .returning();
    if (!row) throw new Error("Failed to insert topup");
    res.status(201).json({
      id: row.id,
      amountVnd: row.amountVnd,
      points: row.points,
      method: row.method,
      status: row.status,
      proofNote: row.proofNote,
      adminNote: row.adminNote,
      createdAt: row.createdAt.toISOString(),
      processedAt: row.processedAt ? row.processedAt.toISOString() : null,
    });
  }),
);

router.get(
  "/account/affiliate",
  requireAuth,
  wrap(async (req, res) => {
    const me = req.currentUser!;
    const referrals = await db
      .select({
        id: usersTable.id,
        name: usersTable.name,
        email: usersTable.email,
        joinedAt: usersTable.createdAt,
      })
      .from(usersTable)
      .where(eq(usersTable.referredByUserId, me.id))
      .orderBy(desc(usersTable.createdAt))
      .limit(50);

    const commissions = await db
      .select()
      .from(commissionsTable)
      .where(eq(commissionsTable.affiliateUserId, me.id))
      .orderBy(desc(commissionsTable.createdAt))
      .limit(50);

    const sourceIds = Array.from(new Set(commissions.map((c) => c.sourceUserId)));
    const sourceUsers =
      sourceIds.length > 0
        ? await db
            .select({ id: usersTable.id, name: usersTable.name })
            .from(usersTable)
        : [];
    const sourceMap = new Map(sourceUsers.map((s) => [s.id, s.name]));

    res.json({
      referralCode: me.referralCode,
      commissionVnd: me.commissionVnd,
      commissionRatePct: COMMISSION_RATE_PCT,
      referredCount: referrals.length,
      recentReferrals: referrals.map((r) => ({
        id: r.id,
        name: r.name,
        email: r.email,
        joinedAt: r.joinedAt.toISOString(),
      })),
      commissions: commissions.map((c) => ({
        id: c.id,
        amountVnd: c.amountVnd,
        status: c.status,
        sourceUserName: sourceMap.get(c.sourceUserId) ?? "Người dùng",
        createdAt: c.createdAt.toISOString(),
      })),
    });
  }),
);

export default router;
