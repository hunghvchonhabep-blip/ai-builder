import { Router, type IRouter, type ErrorRequestHandler } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import accountRouter from "./account";
import sitesRouter from "./sites";
import templatesRouter from "./templates";
import adminRouter from "./admin";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(accountRouter);
router.use(sitesRouter);
router.use(templatesRouter);
router.use(adminRouter);

const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  logger.error({ err }, "Route error");
  const status = (err as { status?: number })?.status ?? 500;
  const message = err instanceof Error ? err.message : "Internal server error";
  res.status(status).json({ error: message });
};
router.use(errorHandler);

export default router;
