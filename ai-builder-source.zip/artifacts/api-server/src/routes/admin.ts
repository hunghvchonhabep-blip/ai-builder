import { Router, type IRouter } from "express";
import {
  db,
  usersTable,
  pointTransactionsTable,
  topupRequestsTable,
  commissionsTable,
  sitesTable,
} from "@workspace/db";
import { desc, eq, sql } from "drizzle-orm";
import {
  AdminAdjustPointsBody as AdjustPointsBody,
  AdminDecideTopupBody as TopupDecisionBody,
} from "@workspace/api-zod";
import { wrap } from "../lib/wrap";
import { requireAdmin } from "../middlewares/auth";
import { COMMISSION_RATE_PCT } from "../lib/pricing";

const router: IRouter = Router();

router.use(requireAdmin);

router.get(
  "/admin/users",
  wrap(async (_req, res) => {
    const users = await db.select().from(usersTable).orderBy(desc(usersTable.createdAt));
    const counts = await db
      .select({
        userId: sitesTable.userId,
        count: sql<number>`count(*)::int`,
      })
      .from(sitesTable)
      .groupBy(sitesTable.userId);
    const countMap = new Map(counts.map((c) => [c.userId ?? "", c.count]));
    res.json(
      users.map((u) => ({
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role,
        points: u.points,
        commissionVnd: u.commissionVnd,
        referralCode: u.referralCode,
        referredByUserId: u.referredByUserId,
        sitesCount: countMap.get(u.id) ?? 0,
        createdAt: u.createdAt.toISOString(),
      })),
    );
  }),
);

router.post(
  "/admin/users/:id/adjust",
  wrap(async (req, res) => {
    const id = req.params.id as string | undefined;
    if (!id) {
      res.status(400).json({ error: "Missing id" });
      return;
    }
    const body = AdjustPointsBody.parse(req.body);
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id));
    if (!user) {
      res.status(404).json({ error: "Không tìm thấy thành viên" });
      return;
    }
    const newPoints = Math.max(0, user.points + body.delta);
    const actualDelta = newPoints - user.points;
    const [updated] = await db
      .update(usersTable)
      .set({ points: newPoints, updatedAt: new Date() })
      .where(eq(usersTable.id, id))
      .returning();
    if (!updated) throw new Error("Failed to update");
    await db.insert(pointTransactionsTable).values({
      userId: id,
      delta: actualDelta,
      reason: `Admin: ${body.reason}`,
    });
    const [count] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sitesTable)
      .where(eq(sitesTable.userId, id));
    res.json({
      id: updated.id,
      email: updated.email,
      name: updated.name,
      role: updated.role,
      points: updated.points,
      commissionVnd: updated.commissionVnd,
      referralCode: updated.referralCode,
      referredByUserId: updated.referredByUserId,
      sitesCount: count?.count ?? 0,
      createdAt: updated.createdAt.toISOString(),
    });
  }),
);

router.get(
  "/admin/topups",
  wrap(async (_req, res) => {
    const rows = await db
      .select({
        topup: topupRequestsTable,
        user: { name: usersTable.name, email: usersTable.email },
      })
      .from(topupRequestsTable)
      .leftJoin(usersTable, eq(usersTable.id, topupRequestsTable.userId))
      .orderBy(desc(topupRequestsTable.createdAt));
    res.json(
      rows.map((r) => ({
        id: r.topup.id,
        userId: r.topup.userId,
        userName: r.user?.name ?? "—",
        userEmail: r.user?.email ?? "—",
        amountVnd: r.topup.amountVnd,
        points: r.topup.points,
        method: r.topup.method,
        status: r.topup.status,
        proofNote: r.topup.proofNote,
        adminNote: r.topup.adminNote,
        createdAt: r.topup.createdAt.toISOString(),
        processedAt: r.topup.processedAt ? r.topup.processedAt.toISOString() : null,
      })),
    );
  }),
);

router.post(
  "/admin/topups/:id/decision",
  wrap(async (req, res) => {
    const id = req.params.id as string | undefined;
    if (!id) {
      res.status(400).json({ error: "Missing id" });
      return;
    }
    const body = TopupDecisionBody.parse(req.body);
    const [topup] = await db
      .select()
      .from(topupRequestsTable)
      .where(eq(topupRequestsTable.id, id));
    if (!topup) {
      res.status(404).json({ error: "Không tìm thấy yêu cầu" });
      return;
    }
    if (topup.status !== "pending") {
      res.status(400).json({ error: "Yêu cầu này đã được xử lý" });
      return;
    }
    const newStatus = body.decision === "approve" ? "approved" : "rejected";
    const [updated] = await db
      .update(topupRequestsTable)
      .set({
        status: newStatus,
        adminNote: body.adminNote ?? null,
        processedAt: new Date(),
      })
      .where(eq(topupRequestsTable.id, id))
      .returning();
    if (!updated) throw new Error("Failed to update topup");

    if (body.decision === "approve") {
      // Credit the user
      const [user] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, topup.userId));
      if (user) {
        await db
          .update(usersTable)
          .set({ points: user.points + topup.points, updatedAt: new Date() })
          .where(eq(usersTable.id, user.id));
        await db.insert(pointTransactionsTable).values({
          userId: user.id,
          delta: topup.points,
          reason: `Nạp ${topup.amountVnd.toLocaleString("vi-VN")}đ qua ${topup.method}`,
        });

        if (user.referredByUserId) {
          const commissionVnd = Math.floor(
            (topup.amountVnd * COMMISSION_RATE_PCT) / 100,
          );
          if (commissionVnd > 0) {
            await db.insert(commissionsTable).values({
              affiliateUserId: user.referredByUserId,
              sourceUserId: user.id,
              sourceTopupId: topup.id,
              amountVnd: commissionVnd,
              note: `Hoa hồng ${COMMISSION_RATE_PCT}% từ ${user.name}`,
            });
            const [aff] = await db
              .select({ commissionVnd: usersTable.commissionVnd })
              .from(usersTable)
              .where(eq(usersTable.id, user.referredByUserId));
            if (aff) {
              await db
                .update(usersTable)
                .set({
                  commissionVnd: aff.commissionVnd + commissionVnd,
                  updatedAt: new Date(),
                })
                .where(eq(usersTable.id, user.referredByUserId));
            }
          }
        }
      }
    }

    const [u] = await db
      .select({ name: usersTable.name, email: usersTable.email })
      .from(usersTable)
      .where(eq(usersTable.id, updated.userId));
    res.json({
      id: updated.id,
      userId: updated.userId,
      userName: u?.name ?? "—",
      userEmail: u?.email ?? "—",
      amountVnd: updated.amountVnd,
      points: updated.points,
      method: updated.method,
      status: updated.status,
      proofNote: updated.proofNote,
      adminNote: updated.adminNote,
      createdAt: updated.createdAt.toISOString(),
      processedAt: updated.processedAt ? updated.processedAt.toISOString() : null,
    });
  }),
);

router.get(
  "/admin/commissions",
  wrap(async (_req, res) => {
    const rows = await db
      .select()
      .from(commissionsTable)
      .orderBy(desc(commissionsTable.createdAt));
    const userIds = Array.from(
      new Set(rows.flatMap((r) => [r.affiliateUserId, r.sourceUserId])),
    );
    const users =
      userIds.length > 0
        ? await db
            .select({ id: usersTable.id, name: usersTable.name })
            .from(usersTable)
        : [];
    const map = new Map(users.map((u) => [u.id, u.name]));
    res.json(
      rows.map((r) => ({
        id: r.id,
        affiliateUserId: r.affiliateUserId,
        affiliateName: map.get(r.affiliateUserId) ?? "—",
        sourceUserName: map.get(r.sourceUserId) ?? "—",
        amountVnd: r.amountVnd,
        status: r.status,
        note: r.note,
        createdAt: r.createdAt.toISOString(),
        paidAt: r.paidAt ? r.paidAt.toISOString() : null,
      })),
    );
  }),
);

router.post(
  "/admin/commissions/:id/pay",
  wrap(async (req, res) => {
    const id = req.params.id as string | undefined;
    if (!id) {
      res.status(400).json({ error: "Missing id" });
      return;
    }
    const [row] = await db
      .select()
      .from(commissionsTable)
      .where(eq(commissionsTable.id, id));
    if (!row) {
      res.status(404).json({ error: "Không tìm thấy" });
      return;
    }
    if (row.status === "paid") {
      res.status(400).json({ error: "Đã thanh toán rồi" });
      return;
    }
    const [updated] = await db
      .update(commissionsTable)
      .set({ status: "paid", paidAt: new Date() })
      .where(eq(commissionsTable.id, id))
      .returning();
    if (!updated) throw new Error("Failed to update");

    const [aff] = await db
      .select({ commissionVnd: usersTable.commissionVnd })
      .from(usersTable)
      .where(eq(usersTable.id, updated.affiliateUserId));
    if (aff) {
      await db
        .update(usersTable)
        .set({
          commissionVnd: Math.max(0, aff.commissionVnd - updated.amountVnd),
          updatedAt: new Date(),
        })
        .where(eq(usersTable.id, updated.affiliateUserId));
    }

    const users = await db
      .select({ id: usersTable.id, name: usersTable.name })
      .from(usersTable);
    const map = new Map(users.map((u) => [u.id, u.name]));
    res.json({
      id: updated.id,
      affiliateUserId: updated.affiliateUserId,
      affiliateName: map.get(updated.affiliateUserId) ?? "—",
      sourceUserName: map.get(updated.sourceUserId) ?? "—",
      amountVnd: updated.amountVnd,
      status: updated.status,
      note: updated.note,
      createdAt: updated.createdAt.toISOString(),
      paidAt: updated.paidAt ? updated.paidAt.toISOString() : null,
    });
  }),
);

export default router;
