import { Router, type IRouter } from "express";
import { db, sitesTable, usersTable, pointTransactionsTable } from "@workspace/db";
import { and, desc, eq, sql, gte } from "drizzle-orm";
import {
  GenerateSiteBody,
  CreateSiteBody,
  UpdateSiteBody,
  RefineSiteBody,
} from "@workspace/api-zod";
import {
  generateSiteFromPrompt,
  refineSiteWithInstruction,
  type SiteFormat,
  type SiteFile,
} from "../lib/generator";
import { wrap } from "../lib/wrap";
import { requireAuth } from "../middlewares/auth";
import { GENERATE_COST, REFINE_COST } from "../lib/pricing";

const router: IRouter = Router();

type SiteRow = typeof sitesTable.$inferSelect;
function serializeSite(row: SiteRow) {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    prompt: row.prompt,
    html: row.html,
    format: (row.format ?? "html") as SiteFormat,
    files: (row.files ?? []) as SiteFile[],
    industry: row.industry,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function userScope(userId: string | null) {
  return userId ? eq(sitesTable.userId, userId) : sql`1=0`;
}

router.get(
  "/sites",
  requireAuth,
  wrap(async (req, res) => {
    const userId = req.currentUser!.id;
    const isAdmin = req.currentUser!.role === "admin";
    const rows = await db
      .select({
        id: sitesTable.id,
        title: sitesTable.title,
        description: sitesTable.description,
        industry: sitesTable.industry,
        updatedAt: sitesTable.updatedAt,
      })
      .from(sitesTable)
      .where(isAdmin ? sql`1=1` : userScope(userId))
      .orderBy(desc(sitesTable.updatedAt));
    res.json(
      rows.map((r) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        industry: r.industry,
        updatedAt: r.updatedAt.toISOString(),
      })),
    );
  }),
);

router.get(
  "/sites/recent",
  wrap(async (req, res) => {
    if (!req.currentUser) {
      res.json([]);
      return;
    }
    const userId = req.currentUser.id;
    const isAdmin = req.currentUser.role === "admin";
    const rows = await db
      .select({
        id: sitesTable.id,
        title: sitesTable.title,
        description: sitesTable.description,
        industry: sitesTable.industry,
        updatedAt: sitesTable.updatedAt,
      })
      .from(sitesTable)
      .where(isAdmin ? sql`1=1` : userScope(userId))
      .orderBy(desc(sitesTable.updatedAt))
      .limit(6);
    res.json(
      rows.map((r) => ({
        id: r.id,
        title: r.title,
        description: r.description,
        industry: r.industry,
        updatedAt: r.updatedAt.toISOString(),
      })),
    );
  }),
);

router.get(
  "/sites/stats",
  wrap(async (req, res) => {
    if (!req.currentUser) {
      res.json({ totalSites: 0, sitesThisWeek: 0, topIndustries: [] });
      return;
    }
    const userId = req.currentUser.id;
    const isAdmin = req.currentUser.role === "admin";
    const scope = isAdmin ? sql`1=1` : userScope(userId);
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const [totalRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sitesTable)
      .where(scope);
    const [weekRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sitesTable)
      .where(and(scope, gte(sitesTable.createdAt, oneWeekAgo)));
    const industryRows = await db
      .select({
        industry: sitesTable.industry,
        count: sql<number>`count(*)::int`,
      })
      .from(sitesTable)
      .where(scope)
      .groupBy(sitesTable.industry)
      .orderBy(desc(sql`count(*)`))
      .limit(5);

    res.json({
      totalSites: totalRow?.count ?? 0,
      sitesThisWeek: weekRow?.count ?? 0,
      topIndustries: industryRows
        .filter((r) => r.industry)
        .map((r) => ({ industry: r.industry as string, count: r.count })),
    });
  }),
);

async function chargePoints(
  userId: string,
  cost: number,
  reason: string,
  siteId: string | null,
): Promise<boolean> {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user || user.points < cost) return false;
  await db
    .update(usersTable)
    .set({ points: user.points - cost, updatedAt: new Date() })
    .where(eq(usersTable.id, userId));
  await db.insert(pointTransactionsTable).values({
    userId,
    delta: -cost,
    reason,
    siteId: siteId ?? null,
  });
  return true;
}

router.post(
  "/sites/generate",
  requireAuth,
  wrap(async (req, res) => {
    const body = GenerateSiteBody.parse(req.body);
    const me = req.currentUser!;
    if (me.points < GENERATE_COST) {
      res.status(402).json({
        error: `Bạn cần ít nhất ${GENERATE_COST} điểm để tạo dự án mới. Vui lòng nạp thêm điểm.`,
      });
      return;
    }
    const format = (body.format ?? "html") as SiteFormat;
    const generated = await generateSiteFromPrompt(
      body.prompt,
      body.industry ?? null,
      body.style ?? null,
      format,
    );
    const [row] = await db
      .insert(sitesTable)
      .values({
        userId: me.id,
        title: generated.title,
        description: generated.description,
        prompt: body.prompt,
        html: generated.html,
        format: generated.format,
        files: generated.files,
        industry: generated.industry,
      })
      .returning();
    if (!row) throw new Error("Failed to insert");
    const ok = await chargePoints(
      me.id,
      GENERATE_COST,
      `Tạo dự án "${generated.title}"`,
      row.id,
    );
    if (!ok) {
      // Race - shouldn't happen but be safe.
      await db.delete(sitesTable).where(eq(sitesTable.id, row.id));
      res.status(402).json({ error: "Không đủ điểm" });
      return;
    }
    res.json(serializeSite(row));
  }),
);

router.post(
  "/sites",
  requireAuth,
  wrap(async (req, res) => {
    const body = CreateSiteBody.parse(req.body);
    const [row] = await db
      .insert(sitesTable)
      .values({
        userId: req.currentUser!.id,
        title: body.title,
        description: body.description,
        prompt: body.prompt,
        html: body.html,
        industry: body.industry ?? null,
      })
      .returning();
    if (!row) throw new Error("Failed to insert");
    res.status(201).json(serializeSite(row));
  }),
);

async function loadOwnedSite(req: import("express").Request) {
  const id = req.params.id as string | undefined;
  if (!id) return { error: 400 as const };
  const [row] = await db.select().from(sitesTable).where(eq(sitesTable.id, id));
  if (!row) return { error: 404 as const };
  const me = req.currentUser;
  if (!me) return { error: 401 as const };
  if (row.userId && row.userId !== me.id && me.role !== "admin") {
    return { error: 403 as const };
  }
  return { row };
}

router.get(
  "/sites/:id",
  requireAuth,
  wrap(async (req, res) => {
    const r = await loadOwnedSite(req);
    if ("error" in r) {
      res.status(r.error).json({ error: "Không tìm thấy hoặc không có quyền" });
      return;
    }
    res.json(serializeSite(r.row));
  }),
);

router.patch(
  "/sites/:id",
  requireAuth,
  wrap(async (req, res) => {
    const r = await loadOwnedSite(req);
    if ("error" in r) {
      res.status(r.error).json({ error: "Không tìm thấy hoặc không có quyền" });
      return;
    }
    const body = UpdateSiteBody.parse(req.body);
    const update: Record<string, unknown> = { updatedAt: new Date() };
    if (body.title !== undefined) update.title = body.title;
    if (body.description !== undefined) update.description = body.description;
    if (body.html !== undefined) update.html = body.html;
    if (body.industry !== undefined) update.industry = body.industry;
    const [row] = await db
      .update(sitesTable)
      .set(update)
      .where(eq(sitesTable.id, r.row.id))
      .returning();
    if (!row) throw new Error("Update failed");
    res.json(serializeSite(row));
  }),
);

router.delete(
  "/sites/:id",
  requireAuth,
  wrap(async (req, res) => {
    const r = await loadOwnedSite(req);
    if ("error" in r) {
      res.status(r.error).json({ error: "Không tìm thấy hoặc không có quyền" });
      return;
    }
    await db.delete(sitesTable).where(eq(sitesTable.id, r.row.id));
    res.status(204).end();
  }),
);

router.post(
  "/sites/:id/refine",
  requireAuth,
  wrap(async (req, res) => {
    const r = await loadOwnedSite(req);
    if ("error" in r) {
      res.status(r.error).json({ error: "Không tìm thấy hoặc không có quyền" });
      return;
    }
    const me = req.currentUser!;
    if (me.points < REFINE_COST) {
      res.status(402).json({
        error: `Bạn cần ít nhất ${REFINE_COST} điểm để tinh chỉnh.`,
      });
      return;
    }
    const body = RefineSiteBody.parse(req.body);
    const current = r.row;
    const refined = await refineSiteWithInstruction(
      current.html,
      (current.files ?? []) as SiteFile[],
      ((current.format ?? "html") as SiteFormat),
      current.title,
      current.description,
      current.industry,
      body.instruction,
    );
    const [row] = await db
      .update(sitesTable)
      .set({
        title: refined.title,
        description: refined.description,
        html: refined.html,
        format: refined.format,
        files: refined.files,
        industry: refined.industry,
        updatedAt: new Date(),
      })
      .where(eq(sitesTable.id, current.id))
      .returning();
    if (!row) throw new Error("Failed to update");
    await chargePoints(
      me.id,
      REFINE_COST,
      `Tinh chỉnh dự án "${row.title}"`,
      row.id,
    );
    res.json(serializeSite(row));
  }),
);

export default router;
