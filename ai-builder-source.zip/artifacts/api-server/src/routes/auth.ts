import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable, pointTransactionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { RegisterBody, LoginBody } from "@workspace/api-zod";
import { wrap } from "../lib/wrap";
import { serializeMe } from "../lib/serializers";
import { SIGNUP_BONUS } from "../lib/pricing";

const router: IRouter = Router();

function makeReferralCode(): string {
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}

router.post(
  "/auth/register",
  wrap(async (req, res) => {
    const body = RegisterBody.parse(req.body);
    const email = body.email.trim().toLowerCase();

    const [existing] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.email, email));
    if (existing) {
      res.status(400).json({ error: "Email đã được sử dụng" });
      return;
    }

    let referredByUserId: string | null = null;
    if (body.referralCode) {
      const code = body.referralCode.trim().toUpperCase();
      if (code) {
        const [referrer] = await db
          .select({ id: usersTable.id })
          .from(usersTable)
          .where(eq(usersTable.referralCode, code));
        if (referrer) referredByUserId = referrer.id;
      }
    }

    const passwordHash = await bcrypt.hash(body.password, 10);
    let referralCode = makeReferralCode();
    for (let attempt = 0; attempt < 5; attempt++) {
      const [taken] = await db
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.referralCode, referralCode));
      if (!taken) break;
      referralCode = makeReferralCode();
    }

    const isFirstUser = !(
      await db.select({ id: usersTable.id }).from(usersTable).limit(1)
    ).length;

    const [user] = await db
      .insert(usersTable)
      .values({
        email,
        passwordHash,
        name: body.name.trim(),
        role: isFirstUser ? "admin" : "user",
        points: SIGNUP_BONUS,
        referralCode,
        referredByUserId,
      })
      .returning();
    if (!user) throw new Error("Failed to create user");

    await db.insert(pointTransactionsTable).values({
      userId: user.id,
      delta: SIGNUP_BONUS,
      reason: "Tặng điểm chào mừng khi đăng ký",
    });

    req.session.userId = user.id;
    res.json(serializeMe(user));
  }),
);

router.post(
  "/auth/login",
  wrap(async (req, res) => {
    const body = LoginBody.parse(req.body);
    const email = body.email.trim().toLowerCase();
    const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
    if (!user) {
      res.status(401).json({ error: "Email hoặc mật khẩu không đúng" });
      return;
    }
    const ok = await bcrypt.compare(body.password, user.passwordHash);
    if (!ok) {
      res.status(401).json({ error: "Email hoặc mật khẩu không đúng" });
      return;
    }
    req.session.userId = user.id;
    res.json(serializeMe(user));
  }),
);

router.post(
  "/auth/logout",
  wrap(async (req, res) => {
    await new Promise<void>((resolve, reject) => {
      req.session.destroy((err) => (err ? reject(err) : resolve()));
    });
    res.clearCookie("aib.sid");
    res.status(204).end();
  }),
);

router.get("/auth/me", (req, res) => {
  if (!req.currentUser) {
    res.json({ user: null });
    return;
  }
  res.json({ user: serializeMe(req.currentUser) });
});

export default router;
