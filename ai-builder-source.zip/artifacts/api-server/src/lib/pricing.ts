export const SIGNUP_BONUS = 100;
export const GENERATE_COST = 10;
export const REFINE_COST = 5;
export const COMMISSION_RATE_PCT = 10;

export type PricingTier = {
  amountVnd: number;
  points: number;
  bonusPct: number;
  label: string;
};

export const PRICING_TIERS: PricingTier[] = [
  { amountVnd: 50_000, points: 50, bonusPct: 0, label: "Gói Khởi Đầu" },
  { amountVnd: 100_000, points: 120, bonusPct: 20, label: "Gói Tiêu Chuẩn" },
  { amountVnd: 300_000, points: 400, bonusPct: 33, label: "Gói Phổ Biến" },
  { amountVnd: 1_000_000, points: 1500, bonusPct: 50, label: "Gói Doanh Nghiệp" },
];

export function pointsForAmount(amountVnd: number): number {
  const exact = PRICING_TIERS.find((t) => t.amountVnd === amountVnd);
  if (exact) return exact.points;
  return Math.floor(amountVnd / 1000);
}
