import { openai } from "./openai-client";
import { logger } from "./logger";

export type SiteFile = { path: string; content: string };
export type SiteFormat = "html" | "php" | "nodejs" | "wordpress";

export type GeneratedSite = {
  title: string;
  description: string;
  industry: string | null;
  format: SiteFormat;
  html: string;
  files: SiteFile[];
};

const FORMAT_INSTRUCTIONS: Record<SiteFormat, string> = {
  html: `OUTPUT FORMAT: Plain static HTML.
- Produce ONE file: \`index.html\`. It must be a complete HTML5 document starting with <!DOCTYPE html>.
- Use TailwindCSS via <script src="https://cdn.tailwindcss.com"></script> in <head>.
- The "previewHtml" field must be IDENTICAL to the content of \`index.html\`.`,

  php: `OUTPUT FORMAT: Plain PHP.
- Produce these files:
  - \`index.php\` — a complete PHP page that prints a full HTML5 document. Use TailwindCSS CDN. Add a small PHP block at the top to handle a contact form POST (validate name + email + message, store nothing, just show a thank-you message via a $success variable echoed in the markup). Use <?php ... ?> blocks meaningfully.
  - \`README.md\` — short Vietnamese-or-English instructions on how to run with \`php -S localhost:8000\` and how to deploy to a shared host (cPanel/FTP).
- The "previewHtml" field must be the rendered HTML output of \`index.php\` AS IF the PHP had executed with no form submission yet (i.e. resolve the PHP and produce the resulting HTML5 document with the Tailwind CDN script).`,

  nodejs: `OUTPUT FORMAT: Node.js + Express.
- Produce these files:
  - \`server.js\` — Express server that serves the landing page at \`/\` (rendering an HTML string) and a POST \`/contact\` endpoint that accepts JSON {name,email,message} and responds {ok:true}. Use ES modules ("import" syntax). Listen on \`process.env.PORT || 3000\`.
  - \`package.json\` — name based on slug, type:"module", scripts.start = "node server.js", dependency "express": "^4.19.2".
  - \`README.md\` — instructions: \`npm install\`, \`npm start\`.
- The "previewHtml" field must be the exact HTML5 document the server would respond with at \`/\` (Tailwind CDN + full landing page).`,

  wordpress: `OUTPUT FORMAT: WordPress classic theme.
- Produce these files for a working theme folder:
  - \`style.css\` — header comment with Theme Name, Author, Description (in the user's language), Version 1.0, plus a few base styles.
  - \`functions.php\` — \`add_theme_support('title-tag')\`, \`add_theme_support('post-thumbnails')\`, \`register_nav_menus(['primary'=>'Primary Menu'])\`, and an \`enqueue_scripts\` action that enqueues Tailwind CDN and the theme stylesheet.
  - \`header.php\` — opens <!DOCTYPE html>, <html <?php language_attributes(); ?>>, <head> with <?php wp_head(); ?>, opens <body <?php body_class(); ?>>, includes site nav.
  - \`index.php\` — calls get_header(), then renders the FULL landing page (hero, features, testimonials, CTA, etc.) using static HTML markup mixed with WordPress template tags where appropriate (e.g. <?php bloginfo('name'); ?>), then get_footer().
  - \`footer.php\` — closing footer markup, <?php wp_footer(); ?>, </body></html>.
  - \`README.md\` — short instructions to zip the folder, upload via WP Admin → Appearance → Themes → Add New.
- The "previewHtml" field must be a complete HTML5 document representing what the theme renders on the homepage (Tailwind CDN included), so it can be previewed in an iframe without WordPress.`,
};

const SHARED_DESIGN_RULES = `DESIGN RULES (apply to previewHtml and to the rendered output of the chosen format):
- Build a rich, scroll-worthy page: hero, features/benefits, social proof or testimonials, how-it-works or showcase, CTA, footer. 5-7 sections total.
- Use real, specific copy in the SAME LANGUAGE as the user's prompt (Vietnamese stays Vietnamese, English stays English). No lorem ipsum.
- Tasteful Google Fonts pairing via <link> in <head> (e.g. Plus Jakarta Sans + Playfair Display).
- Deliberate, memorable color palette appropriate to the brand/industry.
- Use placeholder images from https://images.unsplash.com/photo-... matching the topic, OR inline SVG / CSS gradients.
- Inline SVG icons (heroicons style) only — never external icon libraries.
- Responsive (mobile-first), accessible color contrast, semantic HTML.
- No <script> tags other than the Tailwind CDN.`;

const SYSTEM_PROMPT = `You are an elite web designer and full-stack engineer who delivers production-ready landing pages in multiple stacks (HTML, PHP, Node.js/Express, WordPress themes).

CRITICAL RULES:
- Output VALID JSON only matching the schema described in the user message. No markdown fences, no commentary.
- Honor the requested OUTPUT FORMAT exactly.
- The "files" array MUST contain every file needed for the chosen format, with FULL contents (no truncation, no "...rest of code...").
- The "previewHtml" field is ALWAYS a complete, standalone HTML5 document with the Tailwind CDN, suitable for direct iframe rendering.

${SHARED_DESIGN_RULES}`;

const USER_TEMPLATE = (
  prompt: string,
  industry: string | null,
  style: string | null,
  format: SiteFormat,
) => `Create a landing page based on this brief:

PROMPT: ${prompt}
${industry ? `INDUSTRY: ${industry}` : ""}
${style ? `STYLE PREFERENCE: ${style}` : ""}

${FORMAT_INSTRUCTIONS[format]}

Return JSON with this exact shape:
{
  "title": "<short page title, language matching prompt>",
  "description": "<one-sentence summary in same language as prompt>",
  "industry": "<short industry tag in english, e.g. 'restaurant', 'saas', 'fashion'>",
  "previewHtml": "<complete HTML5 document with Tailwind CDN, rendered preview>",
  "files": [
    { "path": "<filename>", "content": "<full file contents>" }
  ]
}`;

type RawAiResponse = {
  title?: string;
  description?: string;
  industry?: string | null;
  previewHtml?: string;
  files?: SiteFile[];
};

function normalize(
  raw: RawAiResponse,
  format: SiteFormat,
  fallbackTitle: string,
  fallbackDescription: string,
  fallbackIndustry: string | null,
): GeneratedSite {
  const previewHtml = raw.previewHtml ?? "";
  let files = Array.isArray(raw.files) ? raw.files : [];
  files = files.filter(
    (f): f is SiteFile =>
      !!f && typeof f.path === "string" && typeof f.content === "string",
  );
  if (format === "html") {
    if (files.length === 0) {
      files = [{ path: "index.html", content: previewHtml }];
    }
  }
  if (!previewHtml) {
    throw new Error("AI response missing previewHtml");
  }
  if (files.length === 0) {
    throw new Error("AI response missing files");
  }
  return {
    title: raw.title ?? fallbackTitle,
    description: raw.description ?? fallbackDescription,
    industry: raw.industry ?? fallbackIndustry,
    format,
    html: previewHtml,
    files,
  };
}

export async function generateSiteFromPrompt(
  prompt: string,
  industry: string | null,
  style: string | null,
  format: SiteFormat = "html",
): Promise<GeneratedSite> {
  logger.info(
    { prompt: prompt.slice(0, 80), format },
    "Generating site",
  );

  const completion = await openai.chat.completions.create({
    model: "gpt-5.4",
    max_completion_tokens: 20000,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: USER_TEMPLATE(prompt, industry, style, format) },
    ],
  });

  const content = completion.choices[0]?.message?.content;
  if (!content) {
    throw new Error("AI returned empty response");
  }

  const parsed = JSON.parse(content) as RawAiResponse;
  return normalize(parsed, format, "Untitled", "", industry);
}

const REFINE_SYSTEM = `You are an elite full-stack engineer. You take an existing project (preview HTML + project files in a specific format) and a user instruction, then return an improved version.

CRITICAL RULES:
- Output VALID JSON only with shape: { "title", "description", "industry", "previewHtml", "files": [{path, content}] }.
- Preserve the chosen OUTPUT FORMAT and overall structure unless the user explicitly asks for a redesign.
- Apply the user's instruction precisely to BOTH the previewHtml and the corresponding source files so they stay in sync.
- The previewHtml MUST remain a complete HTML5 document with the Tailwind CDN.
- Same language as the existing page content. Keep title/description/industry the same unless the instruction implies otherwise.
- Return EVERY file in full, no truncation.
- No commentary, no markdown fences.`;

export async function refineSiteWithInstruction(
  currentHtml: string,
  currentFiles: SiteFile[],
  format: SiteFormat,
  currentTitle: string,
  currentDescription: string,
  currentIndustry: string | null,
  instruction: string,
): Promise<GeneratedSite> {
  logger.info({ instruction: instruction.slice(0, 80), format }, "Refining site");

  const filesBlock = currentFiles
    .map((f) => `--- FILE: ${f.path} ---\n${f.content}`)
    .join("\n\n");

  const completion = await openai.chat.completions.create({
    model: "gpt-5.4",
    max_completion_tokens: 20000,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: REFINE_SYSTEM },
      {
        role: "user",
        content: `OUTPUT FORMAT: ${format}
CURRENT TITLE: ${currentTitle}
CURRENT DESCRIPTION: ${currentDescription}
CURRENT INDUSTRY: ${currentIndustry ?? ""}

CURRENT PREVIEW HTML:
${currentHtml}

CURRENT FILES:
${filesBlock}

USER INSTRUCTION:
${instruction}

Return the updated JSON with the same shape and same OUTPUT FORMAT.`,
      },
    ],
  });

  const content = completion.choices[0]?.message?.content;
  if (!content) {
    throw new Error("AI returned empty response");
  }
  const parsed = JSON.parse(content) as RawAiResponse;
  return normalize(parsed, format, currentTitle, currentDescription, currentIndustry);
}
