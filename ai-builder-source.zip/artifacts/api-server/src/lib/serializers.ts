import type { User } from "@workspace/db";

export function serializeMe(u: User) {
  return {
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role,
    points: u.points,
    referralCode: u.referralCode,
    commissionVnd: u.commissionVnd,
    createdAt: u.createdAt.toISOString(),
  };
}
