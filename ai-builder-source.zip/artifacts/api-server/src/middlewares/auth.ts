import type { Request, Response, NextFunction } from "express";
import { db, usersTable, type User } from "@workspace/db";
import { eq } from "drizzle-orm";

declare module "express-serve-static-core" {
  interface Request {
    currentUser?: User;
  }
}

export async function loadUser(
  req: Request,
  _res: Response,
  next: NextFunction,
): Promise<void> {
  const userId = req.session?.userId;
  if (!userId) {
    next();
    return;
  }
  const [row] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (row) {
    req.currentUser = row;
  }
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  if (!req.currentUser) {
    res.status(401).json({ error: "Yêu cầu đăng nhập" });
    return;
  }
  next();
}

export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  if (!req.currentUser) {
    res.status(401).json({ error: "Yêu cầu đăng nhập" });
    return;
  }
  if (req.currentUser.role !== "admin") {
    res.status(403).json({ error: "Chỉ admin mới có quyền truy cập" });
    return;
  }
  next();
}
