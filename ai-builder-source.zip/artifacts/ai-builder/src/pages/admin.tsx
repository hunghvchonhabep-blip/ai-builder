import { useState } from "react";
import { CheckCircle2, XCircle, Plus, Minus, Wallet, Users } from "lucide-react";
import { Layout } from "@/components/layout";
import { AdminGate } from "@/components/auth-gate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useAdminListUsers,
  useAdminListTopups,
  useAdminListCommissions,
  useAdminAdjustPoints,
  useAdminDecideTopup,
  useAdminPayCommission,
  getAdminListUsersQueryKey,
  getAdminListTopupsQueryKey,
  getAdminListCommissionsQueryKey,
} from "@workspace/api-client-react";

function formatVnd(n: number) {
  return n.toLocaleString("vi-VN") + "đ";
}

function UsersTab() {
  const { data: users = [] } = useAdminListUsers();
  const adjust = useAdminAdjustPoints();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [editing, setEditing] = useState<string | null>(null);
  const [delta, setDelta] = useState<string>("");
  const [reason, setReason] = useState<string>("");

  const submit = async (id: string) => {
    const d = parseInt(delta, 10);
    if (Number.isNaN(d) || !reason.trim()) {
      toast({ title: "Vui lòng nhập số điểm và lý do", variant: "destructive" });
      return;
    }
    await adjust.mutateAsync({ id, data: { delta: d, reason: reason.trim() } });
    toast({ title: "Đã cập nhật điểm" });
    setEditing(null);
    setDelta("");
    setReason("");
    void qc.invalidateQueries({ queryKey: getAdminListUsersQueryKey() });
  };

  return (
    <div className="border rounded-2xl bg-card overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-muted/50">
          <tr className="text-left">
            <th className="px-4 py-3">Thành viên</th>
            <th className="px-4 py-3">Vai trò</th>
            <th className="px-4 py-3 text-right">Điểm</th>
            <th className="px-4 py-3 text-right">Hoa hồng</th>
            <th className="px-4 py-3 text-right">Dự án</th>
            <th className="px-4 py-3">Mã GT</th>
            <th className="px-4 py-3 text-right">Hành động</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {users.map((u) => (
            <tr key={u.id} data-testid={`user-${u.id}`}>
              <td className="px-4 py-3">
                <div className="font-medium">{u.name}</div>
                <div className="text-xs text-muted-foreground">{u.email}</div>
              </td>
              <td className="px-4 py-3">
                <Badge variant={u.role === "admin" ? "default" : "secondary"}>
                  {u.role}
                </Badge>
              </td>
              <td className="px-4 py-3 text-right font-semibold">{u.points}</td>
              <td className="px-4 py-3 text-right">{formatVnd(u.commissionVnd)}</td>
              <td className="px-4 py-3 text-right">{u.sitesCount}</td>
              <td className="px-4 py-3 font-mono text-xs">{u.referralCode}</td>
              <td className="px-4 py-3 text-right">
                {editing === u.id ? (
                  <div className="flex items-center gap-1 justify-end">
                    <Input
                      value={delta}
                      onChange={(e) => setDelta(e.target.value)}
                      placeholder="±"
                      className="w-20 h-8"
                      data-testid={`input-delta-${u.id}`}
                    />
                    <Input
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      placeholder="Lý do"
                      className="w-32 h-8"
                      data-testid={`input-reason-${u.id}`}
                    />
                    <Button
                      size="sm"
                      onClick={() => submit(u.id)}
                      data-testid={`button-save-${u.id}`}
                    >
                      Lưu
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditing(null)}>
                      Hủy
                    </Button>
                  </div>
                ) : (
                  <div className="flex gap-1 justify-end">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditing(u.id);
                        setDelta("100");
                        setReason("Cộng tay");
                      }}
                      data-testid={`button-add-${u.id}`}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditing(u.id);
                        setDelta("-10");
                        setReason("Trừ tay");
                      }}
                      data-testid={`button-sub-${u.id}`}
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TopupsTab() {
  const { data: topups = [] } = useAdminListTopups();
  const decide = useAdminDecideTopup();
  const qc = useQueryClient();
  const { toast } = useToast();

  const handle = async (id: string, decision: "approve" | "reject") => {
    await decide.mutateAsync({ id, data: { decision } });
    toast({
      title: decision === "approve" ? "Đã duyệt và cộng điểm" : "Đã từ chối",
    });
    void qc.invalidateQueries({ queryKey: getAdminListTopupsQueryKey() });
    void qc.invalidateQueries({ queryKey: getAdminListUsersQueryKey() });
    void qc.invalidateQueries({ queryKey: getAdminListCommissionsQueryKey() });
  };

  return (
    <div className="border rounded-2xl bg-card overflow-hidden">
      <ul className="divide-y">
        {topups.length === 0 && (
          <li className="p-8 text-center text-sm text-muted-foreground">
            Chưa có yêu cầu nạp nào.
          </li>
        )}
        {topups.map((t) => (
          <li
            key={t.id}
            className="px-5 py-3 flex items-center justify-between gap-4 flex-wrap"
            data-testid={`topup-${t.id}`}
          >
            <div className="flex-1 min-w-0">
              <div className="font-medium">
                {t.userName} <span className="text-muted-foreground">({t.userEmail})</span>
              </div>
              <div className="text-sm">
                {formatVnd(t.amountVnd)} → <b className="text-primary">{t.points} điểm</b>{" "}
                qua <b>{t.method.toUpperCase()}</b>
              </div>
              {t.proofNote && (
                <div className="text-xs text-muted-foreground mt-1">
                  Ghi chú: {t.proofNote}
                </div>
              )}
              <div className="text-xs text-muted-foreground">
                {new Date(t.createdAt).toLocaleString("vi-VN")}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {t.status === "pending" ? (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-rose-600"
                    onClick={() => handle(t.id, "reject")}
                    data-testid={`button-reject-${t.id}`}
                  >
                    <XCircle className="h-4 w-4 mr-1" /> Từ chối
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handle(t.id, "approve")}
                    data-testid={`button-approve-${t.id}`}
                  >
                    <CheckCircle2 className="h-4 w-4 mr-1" /> Duyệt
                  </Button>
                </>
              ) : (
                <Badge
                  className={
                    t.status === "approved"
                      ? "bg-emerald-100 text-emerald-700"
                      : "bg-rose-100 text-rose-700"
                  }
                >
                  {t.status === "approved" ? "Đã duyệt" : "Đã từ chối"}
                </Badge>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CommissionsTab() {
  const { data: rows = [] } = useAdminListCommissions();
  const pay = useAdminPayCommission();
  const qc = useQueryClient();
  const { toast } = useToast();

  return (
    <div className="border rounded-2xl bg-card overflow-hidden">
      <ul className="divide-y">
        {rows.length === 0 && (
          <li className="p-8 text-center text-sm text-muted-foreground">
            Chưa có hoa hồng nào.
          </li>
        )}
        {rows.map((c) => (
          <li
            key={c.id}
            className="px-5 py-3 flex items-center justify-between"
            data-testid={`commission-${c.id}`}
          >
            <div>
              <div className="font-medium">
                {c.affiliateName}{" "}
                <span className="text-muted-foreground text-sm">
                  ← từ {c.sourceUserName}
                </span>
              </div>
              <div className="text-xs text-muted-foreground">
                {new Date(c.createdAt).toLocaleString("vi-VN")}
                {c.note && ` • ${c.note}`}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-emerald-600">
                {formatVnd(c.amountVnd)}
              </span>
              {c.status === "pending" ? (
                <Button
                  size="sm"
                  onClick={async () => {
                    await pay.mutateAsync({ id: c.id });
                    toast({ title: "Đã đánh dấu đã trả" });
                    void qc.invalidateQueries({
                      queryKey: getAdminListCommissionsQueryKey(),
                    });
                    void qc.invalidateQueries({
                      queryKey: getAdminListUsersQueryKey(),
                    });
                  }}
                  data-testid={`button-pay-${c.id}`}
                >
                  Đánh dấu đã trả
                </Button>
              ) : (
                <Badge className="bg-emerald-100 text-emerald-700">Đã trả</Badge>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Inner() {
  return (
    <div className="container mx-auto p-6 max-w-6xl space-y-4">
      <h1 className="text-2xl font-bold">Trang quản trị</h1>
      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users">
            <Users className="h-4 w-4 mr-1" /> Thành viên
          </TabsTrigger>
          <TabsTrigger value="topups">
            <Wallet className="h-4 w-4 mr-1" /> Yêu cầu nạp
          </TabsTrigger>
          <TabsTrigger value="commissions">Hoa hồng CTV</TabsTrigger>
        </TabsList>
        <TabsContent value="users" className="mt-4">
          <UsersTab />
        </TabsContent>
        <TabsContent value="topups" className="mt-4">
          <TopupsTab />
        </TabsContent>
        <TabsContent value="commissions" className="mt-4">
          <CommissionsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AdminPage() {
  return (
    <Layout>
      <AdminGate>
        <Inner />
      </AdminGate>
    </Layout>
  );
}
