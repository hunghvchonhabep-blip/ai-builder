import { Copy, Users, Wallet, Gift } from "lucide-react";
import { Layout } from "@/components/layout";
import { AuthGate } from "@/components/auth-gate";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useGetMyAffiliate } from "@workspace/api-client-react";

function formatVnd(n: number) {
  return n.toLocaleString("vi-VN") + "đ";
}

function Inner() {
  const { data, isLoading } = useGetMyAffiliate();
  const { toast } = useToast();
  if (isLoading || !data) {
    return (
      <div className="container mx-auto p-6 max-w-4xl text-center text-muted-foreground">
        Đang tải...
      </div>
    );
  }
  const referralLink = `${window.location.origin}/register?ref=${data.referralCode}`;

  const copy = (text: string, label: string) => {
    void navigator.clipboard.writeText(text);
    toast({ title: "Đã sao chép", description: label });
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Chương trình Cộng tác viên</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Mời bạn bè đăng ký và nhận{" "}
          <b className="text-primary">{data.commissionRatePct}% hoa hồng</b> trên mỗi
          lần nạp điểm thành công của họ.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="border rounded-2xl p-5 bg-card">
          <div className="text-sm text-muted-foreground flex items-center gap-1">
            <Users className="h-4 w-4" /> Đã giới thiệu
          </div>
          <div className="text-3xl font-bold mt-1">{data.referredCount}</div>
        </div>
        <div className="border rounded-2xl p-5 bg-card">
          <div className="text-sm text-muted-foreground flex items-center gap-1">
            <Wallet className="h-4 w-4" /> Hoa hồng có thể nhận
          </div>
          <div className="text-3xl font-bold mt-1 text-emerald-600" data-testid="text-commission">
            {formatVnd(data.commissionVnd)}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Liên hệ admin để rút tiền
          </div>
        </div>
        <div className="border rounded-2xl p-5 bg-card">
          <div className="text-sm text-muted-foreground flex items-center gap-1">
            <Gift className="h-4 w-4" /> Tỷ lệ hoa hồng
          </div>
          <div className="text-3xl font-bold mt-1">{data.commissionRatePct}%</div>
        </div>
      </div>

      <div className="border rounded-2xl p-6 bg-card space-y-4">
        <div>
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">
            Mã giới thiệu của bạn
          </Label>
          <div className="flex items-center gap-2 mt-2">
            <code className="text-2xl font-mono font-bold tracking-widest text-primary bg-primary/10 px-4 py-2 rounded-lg">
              {data.referralCode}
            </code>
            <Button
              variant="outline"
              size="sm"
              onClick={() => copy(data.referralCode, "Mã giới thiệu")}
              data-testid="button-copy-code"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div>
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">
            Đường liên kết giới thiệu
          </Label>
          <div className="flex items-center gap-2 mt-2">
            <input
              readOnly
              value={referralLink}
              className="flex-1 border rounded-lg px-3 py-2 text-sm bg-muted font-mono"
              data-testid="input-ref-link"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => copy(referralLink, "Đường liên kết")}
              data-testid="button-copy-link"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="border rounded-2xl bg-card overflow-hidden">
          <div className="px-5 py-4 border-b font-semibold">
            Người được giới thiệu ({data.referredCount})
          </div>
          {data.recentReferrals.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground text-center">
              Chưa có ai đăng ký qua mã của bạn.
            </div>
          ) : (
            <ul className="divide-y">
              {data.recentReferrals.map((r) => (
                <li key={r.id} className="px-5 py-3">
                  <div className="font-medium text-sm">{r.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {r.email} • Tham gia{" "}
                    {new Date(r.joinedAt).toLocaleDateString("vi-VN")}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="border rounded-2xl bg-card overflow-hidden">
          <div className="px-5 py-4 border-b font-semibold">Lịch sử hoa hồng</div>
          {data.commissions.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground text-center">
              Chưa có hoa hồng nào.
            </div>
          ) : (
            <ul className="divide-y">
              {data.commissions.map((c) => (
                <li
                  key={c.id}
                  className="px-5 py-3 flex items-center justify-between"
                >
                  <div>
                    <div className="font-medium text-sm">
                      Từ {c.sourceUserName}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(c.createdAt).toLocaleString("vi-VN")}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-emerald-600">
                      +{formatVnd(c.amountVnd)}
                    </div>
                    <Badge
                      variant="outline"
                      className={
                        c.status === "paid"
                          ? "border-emerald-300 text-emerald-700"
                          : "border-amber-300 text-amber-700"
                      }
                    >
                      {c.status === "paid" ? "Đã trả" : "Chờ trả"}
                    </Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <div className={className}>{children}</div>;
}

export default function AffiliatePage() {
  return (
    <Layout>
      <AuthGate>
        <Inner />
      </AuthGate>
    </Layout>
  );
}
