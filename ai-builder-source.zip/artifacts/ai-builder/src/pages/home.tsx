import { useEffect, useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Loader2, Layout, Zap, ArrowUpRight, Code2, FileCode2, Server, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Layout as AppLayout } from "@/components/layout";
import { SiteCard } from "@/components/site-card";
import { TemplateCard } from "@/components/template-card";
import {
  useListRecentSites,
  useGetSiteStats,
  useListTemplates,
  useGenerateSite,
  useDeleteSite,
  getListRecentSitesQueryKey,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { ApiError, getGetMeQueryKey } from "@workspace/api-client-react";
import { Coins } from "lucide-react";

const LOADING_MESSAGES = [
  "Đang phân tích ý tưởng của bạn...",
  "Đang tìm kiếm bố cục phù hợp nhất...",
  "Đang viết nội dung chuyên nghiệp...",
  "Đang lựa chọn màu sắc và font chữ...",
  "Đang hoàn thiện thiết kế...",
  "Sắp xong rồi, chờ một chút nhé..."
];

type SiteFormat = "html" | "php" | "nodejs" | "wordpress";

const FORMAT_OPTIONS: { value: SiteFormat; label: string; sub: string; icon: typeof Code2 }[] = [
  { value: "html", label: "HTML", sub: "1 file tĩnh", icon: Code2 },
  { value: "php", label: "PHP", sub: "Chạy trên hosting PHP", icon: FileCode2 },
  { value: "nodejs", label: "Node.js", sub: "Express server", icon: Server },
  { value: "wordpress", label: "WordPress", sub: "Theme cài đặt", icon: Globe },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const searchString = useSearch();
  const [prompt, setPrompt] = useState("");
  const [format, setFormat] = useState<SiteFormat>("html");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { me } = useAuth();

  const { data: recentSites, isLoading: loadingRecent } = useListRecentSites();
  const { data: stats, isLoading: loadingStats } = useGetSiteStats();
  const { data: templates, isLoading: loadingTemplates } = useListTemplates();

  const generateSite = useGenerateSite({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        setLocation(`/sites/${data.id}`);
      },
      onError: (error) => {
        if (error instanceof ApiError && error.status === 402) {
          toast({
            title: "Không đủ điểm",
            description:
              (error.data as { error?: string })?.error ??
              "Vui lòng nạp thêm điểm để tiếp tục.",
            variant: "destructive",
          });
          setLocation("/account/topup");
          return;
        }
        toast({
          title: "Lỗi tạo website",
          description:
            error instanceof ApiError
              ? (error.data as { error?: string })?.error ?? error.message
              : "Đã có lỗi xảy ra. Vui lòng thử lại sau.",
          variant: "destructive",
        });
      },
    },
  });

  const deleteSite = useDeleteSite({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListRecentSitesQueryKey() });
        toast({ title: "Đã xóa website" });
      },
    },
  });

  useEffect(() => {
    const params = new URLSearchParams(searchString);
    const initialPrompt = params.get("prompt");
    if (initialPrompt) {
      setPrompt(initialPrompt);
    }
  }, [searchString]);

  const [loadingMessageIndex, setLoadingMessageIndex] = useState(0);

  useEffect(() => {
    if (generateSite.isPending) {
      const interval = setInterval(() => {
        setLoadingMessageIndex((i) => (i + 1) % LOADING_MESSAGES.length);
      }, 1500);
      return () => clearInterval(interval);
    }
    return undefined;
  }, [generateSite.isPending]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    if (!me) {
      toast({
        title: "Vui lòng đăng nhập",
        description: "Bạn cần đăng ký tài khoản miễn phí để tạo website.",
      });
      setLocation(
        `/register?redirect=${encodeURIComponent("/?prompt=" + encodeURIComponent(prompt))}`,
      );
      return;
    }
    generateSite.mutate({ data: { prompt, format } });
  };

  return (
    <AppLayout>
      <div className="flex-1 w-full bg-gradient-to-b from-primary/5 to-background">
        <div className="container mx-auto px-4 py-16 md:py-24 max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center space-y-6 max-w-3xl mx-auto mb-12"
          >
            <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm font-medium text-primary mb-2">
              <Sparkles className="mr-2 h-4 w-4" /> Mới: Tạo website bằng AI trong 30 giây
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground">
              Ý tưởng của bạn. <br className="hidden md:block" />
              <span className="text-primary">Website chuyên nghiệp.</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Chỉ cần mô tả doanh nghiệp, sản phẩm hoặc ý tưởng của bạn. AI của chúng tôi sẽ thiết kế, viết nội dung và hoàn thiện landing page ngay lập tức.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="max-w-3xl mx-auto relative z-10"
          >
            <Card className="p-2 shadow-xl border-primary/20 bg-background/80 backdrop-blur-xl">
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <Textarea
                  placeholder="Ví dụ: Một quán cà phê sách ở Quận 1, không gian yên tĩnh, chuyên cà phê đặc sản và có tổ chức workshop cuối tuần..."
                  className="min-h-[120px] text-base resize-none border-0 focus-visible:ring-0 px-4 py-3 bg-transparent"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  disabled={generateSite.isPending}
                />
                <div className="px-2 pb-1">
                  <div className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">
                    Xuất ra dạng mã
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {FORMAT_OPTIONS.map((opt) => {
                      const Icon = opt.icon;
                      const active = format === opt.value;
                      return (
                        <button
                          type="button"
                          key={opt.value}
                          onClick={() => setFormat(opt.value)}
                          disabled={generateSite.isPending}
                          className={cn(
                            "flex items-center gap-2 rounded-xl border px-3 py-2 text-left transition-all",
                            active
                              ? "border-primary bg-primary/10 text-primary shadow-sm"
                              : "border-border bg-background hover:border-primary/40 hover:bg-muted/50",
                          )}
                        >
                          <Icon className="h-4 w-4 shrink-0" />
                          <div className="min-w-0">
                            <div className="text-sm font-semibold leading-tight truncate">
                              {opt.label}
                            </div>
                            <div className="text-[11px] text-muted-foreground leading-tight truncate">
                              {opt.sub}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div className="flex items-center justify-between px-2 pb-2 gap-2 flex-wrap">
                  <div className="text-xs text-muted-foreground flex items-center gap-2">
                    <span className="flex items-center gap-1">
                      <Zap className="h-3 w-3 text-amber-500" />
                      Mô tả càng chi tiết, kết quả càng ấn tượng
                    </span>
                    {me && (
                      <span className="flex items-center gap-1 text-primary font-medium">
                        <Coins className="h-3 w-3 text-yellow-500" />
                        {me.points} điểm · trừ 10 điểm/lần
                      </span>
                    )}
                  </div>
                  <Button
                    type="submit"
                    size="lg"
                    className="gap-2 rounded-full px-8"
                    disabled={!prompt.trim() || generateSite.isPending}
                  >
                    {generateSite.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Đang tạo...
                      </>
                    ) : (
                      <>
                        Tạo Website <ArrowRight className="h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Card>

            {generateSite.isPending && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-6 text-center"
              >
                <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <motion.span
                    key={loadingMessageIndex}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="min-w-[250px] text-left"
                  >
                    {LOADING_MESSAGES[loadingMessageIndex]}
                  </motion.span>
                </div>
              </motion.div>
            )}
          </motion.div>

          {!loadingStats && stats && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center max-w-4xl mx-auto"
            >
              <div>
                <div className="text-3xl font-bold text-foreground">{stats.totalSites}</div>
                <div className="text-sm text-muted-foreground mt-1">Website đã tạo</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-foreground">{stats.sitesThisWeek}</div>
                <div className="text-sm text-muted-foreground mt-1">Tạo tuần này</div>
              </div>
              {stats.topIndustries.slice(0, 2).map((ind, i) => (
                <div key={ind.industry}>
                  <div className="text-3xl font-bold text-foreground">{ind.count}</div>
                  <div className="text-sm text-muted-foreground mt-1">{ind.industry}</div>
                </div>
              ))}
            </motion.div>
          )}
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 space-y-24">
        {/* Templates Section */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <div className="space-y-1">
              <h2 className="text-2xl font-bold tracking-tight">Cần cảm hứng?</h2>
              <p className="text-muted-foreground">Bắt đầu nhanh với các ý tưởng mẫu</p>
            </div>
            <Button variant="ghost" asChild>
              <Link href="/templates" className="gap-2">
                Xem tất cả <ArrowUpRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          {loadingTemplates ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-48 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : templates && templates.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {templates.slice(0, 3).map((template, i) => (
                <motion.div
                  key={template.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <TemplateCard template={template} />
                </motion.div>
              ))}
            </div>
          ) : null}
        </section>

        {/* Recent Sites Section */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <div className="space-y-1">
              <h2 className="text-2xl font-bold tracking-tight">Dự án gần đây</h2>
              <p className="text-muted-foreground">Tiếp tục chỉnh sửa các website bạn đã tạo</p>
            </div>
            <Button variant="ghost" asChild>
              <Link href="/sites" className="gap-2">
                Quản lý dự án <Layout className="h-4 w-4" />
              </Link>
            </Button>
          </div>
          {loadingRecent ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-64 rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : recentSites && recentSites.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentSites.slice(0, 3).map((site, i) => (
                <motion.div
                  key={site.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <SiteCard 
                    site={site} 
                    onDelete={(id) => deleteSite.mutate({ id })} 
                    isDeleting={deleteSite.isPending} 
                  />
                </motion.div>
              ))}
            </div>
          ) : (
             <div className="text-center py-16 px-4 rounded-xl border border-dashed bg-muted/30">
               <Layout className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
               <h3 className="text-lg font-semibold mb-1">Chưa có dự án nào</h3>
               <p className="text-muted-foreground max-w-sm mx-auto">
                 Hãy thử nhập một ý tưởng ở ô phía trên để AI tạo trang web đầu tiên cho bạn.
               </p>
             </div>
          )}
        </section>
      </div>
    </AppLayout>
  );
}
