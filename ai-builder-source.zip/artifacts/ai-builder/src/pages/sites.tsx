import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Search, Filter, Plus, Layout } from "lucide-react";
import { Layout as AppLayout } from "@/components/layout";
import { SiteCard } from "@/components/site-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListSites,
  useDeleteSite,
  getListSitesQueryKey,
} from "@workspace/api-client-react";

export default function Sites() {
  const [search, setSearch] = useState("");
  const [industry, setIndustry] = useState<string>("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: sites, isLoading } = useListSites();

  const deleteSite = useDeleteSite({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSitesQueryKey() });
        toast({ title: "Đã xóa website" });
      },
      onError: () => {
        toast({ 
          title: "Lỗi xóa website", 
          description: "Không thể xóa website lúc này.",
          variant: "destructive"
        });
      }
    },
  });

  const filteredSites = sites?.filter(site => {
    const matchesSearch = site.title?.toLowerCase().includes(search.toLowerCase()) || 
                          site.description?.toLowerCase().includes(search.toLowerCase());
    const matchesIndustry = industry === "all" || site.industry === industry;
    return matchesSearch && matchesIndustry;
  }) || [];

  const uniqueIndustries = Array.from(new Set(sites?.map(s => s.industry).filter(Boolean) as string[]));

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Dự án của tôi</h1>
            <p className="text-muted-foreground mt-1">Quản lý tất cả các website bạn đã tạo</p>
          </div>
          <Button asChild>
            <Link href="/" className="gap-2">
              <Plus className="h-4 w-4" /> Tạo website mới
            </Link>
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 mb-8">
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Tìm kiếm dự án..."
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={industry} onValueChange={setIndustry}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="Lọc theo lĩnh vực" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tất cả lĩnh vực</SelectItem>
              {uniqueIndustries.map(ind => (
                <SelectItem key={ind} value={ind}>{ind}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-64 rounded-xl bg-muted animate-pulse" />
            ))}
          </div>
        ) : filteredSites.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredSites.map((site, i) => (
              <motion.div
                key={site.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.05, 0.5) }}
              >
                <SiteCard 
                  site={site} 
                  onDelete={(id) => deleteSite.mutate({ id })} 
                  isDeleting={deleteSite.isPending} 
                />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-24 px-4 rounded-xl border border-dashed bg-muted/30">
            <Layout className="mx-auto h-16 w-16 text-muted-foreground/30 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Không tìm thấy dự án</h3>
            <p className="text-muted-foreground max-w-sm mx-auto mb-6">
              {sites?.length === 0 
                ? "Bạn chưa tạo website nào. Hãy bắt đầu bằng cách mô tả ý tưởng của mình."
                : "Không có dự án nào phù hợp với bộ lọc tìm kiếm hiện tại."}
            </p>
            {sites?.length === 0 && (
              <Button asChild size="lg">
                <Link href="/">Tạo ngay</Link>
              </Button>
            )}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
