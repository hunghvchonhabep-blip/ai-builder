import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Sparkles } from "lucide-react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLoginMutation } from "@/hooks/use-auth";
import { ApiError } from "@workspace/api-client-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const login = useLoginMutation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    login.mutate(
      { data: { email, password } },
      {
        onSuccess: () => setLocation("/"),
        onError: (e) => {
          const msg =
            e instanceof ApiError
              ? (e.data as { error?: string })?.error ?? e.message
              : (e as Error).message;
          setErr(msg);
        },
      },
    );
  };

  return (
    <Layout>
      <div className="flex-1 flex items-center justify-center p-6">
        <form
          onSubmit={onSubmit}
          className="w-full max-w-md space-y-5 border rounded-2xl p-8 bg-card shadow-sm"
        >
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary">
              <Sparkles className="h-6 w-6" />
            </div>
            <h1 className="text-2xl font-bold">Đăng nhập</h1>
            <p className="text-sm text-muted-foreground">
              Chào mừng bạn quay lại với AI Builder
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              data-testid="input-email"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Mật khẩu</Label>
            <Input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              data-testid="input-password"
            />
          </div>
          {err && (
            <div className="text-sm text-destructive bg-destructive/10 rounded-md px-3 py-2">
              {err}
            </div>
          )}
          <Button
            type="submit"
            className="w-full"
            disabled={login.isPending}
            data-testid="button-submit-login"
          >
            {login.isPending ? "Đang đăng nhập..." : "Đăng nhập"}
          </Button>
          <p className="text-sm text-center text-muted-foreground">
            Chưa có tài khoản?{" "}
            <Link href="/register" className="text-primary font-medium hover:underline">
              Đăng ký miễn phí
            </Link>
          </p>
        </form>
      </div>
    </Layout>
  );
}
