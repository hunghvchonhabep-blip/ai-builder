import { Link } from "wouter";
import { Coins, ArrowUp, ArrowDown, Plus, Users } from "lucide-react";
import { Layout } from "@/components/layout";
import { AuthGate } from "@/components/auth-gate";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useListMyTransactions } from "@workspace/api-client-react";

function formatDate(s: string) {
  return new Date(s).toLocaleString("vi-VN");
}

function Inner() {
  const { me } = useAuth();
  const { data: txs = [] } = useListMyTransactions();
  if (!me) return null;
  return (
    <div className="container mx-auto p-6 max-w-4xl space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="border rounded-2xl p-5 bg-card">
          <div className="text-sm text-muted-foreground">Họ tên</div>
          <div className="text-lg font-semibold mt-1">{me.name}</div>
          <div className="text-xs text-muted-foreground mt-1">{me.email}</div>
        </div>
        <div className="border rounded-2xl p-5 bg-card">
          <div className="text-sm text-muted-foreground flex items-center gap-1">
            <Coins className="h-4 w-4 text-yellow-500" /> Điểm hiện có
          </div>
          <div className="text-3xl font-bold mt-1" data-testid="text-points">
            {me.points}
          </div>
          <Link href="/account/topup">
            <Button size="sm" className="mt-2" data-testid="button-topup">
              <Plus className="h-4 w-4 mr-1" /> Nạp thêm
            </Button>
          </Link>
        </div>
        <div className="border rounded-2xl p-5 bg-card">
          <div className="text-sm text-muted-foreground flex items-center gap-1">
            <Users className="h-4 w-4" /> Mã giới thiệu
          </div>
          <div className="text-2xl font-mono font-bold mt-1 tracking-widest text-primary">
            {me.referralCode}
          </div>
          <Link href="/account/affiliate">
            <Button size="sm" variant="outline" className="mt-2">
              Trang CTV
            </Button>
          </Link>
        </div>
      </div>

      <div className="border rounded-2xl bg-card overflow-hidden">
        <div className="px-5 py-4 border-b">
          <h2 className="font-semibold">Lịch sử điểm</h2>
        </div>
        {txs.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            Chưa có giao dịch nào.
          </div>
        ) : (
          <ul className="divide-y">
            {txs.map((tx) => (
              <li
                key={tx.id}
                className="flex items-center justify-between px-5 py-3"
                data-testid={`tx-${tx.id}`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`h-8 w-8 rounded-full flex items-center justify-center ${
                      tx.delta >= 0
                        ? "bg-emerald-50 text-emerald-600"
                        : "bg-rose-50 text-rose-600"
                    }`}
                  >
                    {tx.delta >= 0 ? (
                      <ArrowUp className="h-4 w-4" />
                    ) : (
                      <ArrowDown className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <div className="text-sm font-medium">{tx.reason}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatDate(tx.createdAt)}
                    </div>
                  </div>
                </div>
                <div
                  className={`font-semibold ${
                    tx.delta >= 0 ? "text-emerald-600" : "text-rose-600"
                  }`}
                >
                  {tx.delta > 0 ? "+" : ""}
                  {tx.delta}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default function AccountPage() {
  return (
    <Layout>
      <AuthGate>
        <Inner />
      </AuthGate>
    </Layout>
  );
}
