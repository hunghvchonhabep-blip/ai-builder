import { useState, useEffect, useRef, useMemo } from "react";
import { Link, useParams, useLocation } from "wouter";
import { 
  ArrowLeft, ExternalLink, Save, Code, Zap, Monitor, 
  Tablet, Smartphone, Loader2, Trash, Download, FileText
} from "lucide-react";
import JSZip from "jszip";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetSite,
  useUpdateSite,
  useDeleteSite,
  useRefineSite,
  getGetSiteQueryKey,
} from "@workspace/api-client-react";

type ViewportMode = "desktop" | "tablet" | "mobile";

const FORMAT_LABELS: Record<string, string> = {
  html: "HTML tĩnh",
  php: "PHP",
  nodejs: "Node.js / Express",
  wordpress: "WordPress theme",
};

function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/đ/g, "d")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") || "website"
  );
}

export default function SiteEditor() {
  const params = useParams();
  const id = params.id as string;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [instruction, setInstruction] = useState("");
  const [viewport, setViewport] = useState<ViewportMode>("desktop");
  const [isHtmlOpen, setIsHtmlOpen] = useState(false);
  const [activeFile, setActiveFile] = useState<string | null>(null);

  const { data: site, isLoading, error } = useGetSite(id, {
    query: {
      enabled: !!id,
      queryKey: getGetSiteQueryKey(id),
    }
  });

  const initializedRef = useRef<string | null>(null);

  useEffect(() => {
    if (site && initializedRef.current !== id) {
      initializedRef.current = id;
      setTitle(site.title || "");
      setDescription(site.description || "");
    }
  }, [site, id]);

  const files = useMemo(() => site?.files ?? [], [site?.files]);
  const format = site?.format ?? "html";

  useEffect(() => {
    if (files.length > 0 && (!activeFile || !files.find((f) => f.path === activeFile))) {
      setActiveFile(files[0]!.path);
    }
  }, [files, activeFile]);

  const currentFile = files.find((f) => f.path === activeFile) ?? null;

  const updateSite = useUpdateSite({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Đã lưu thay đổi" });
        queryClient.setQueryData(getGetSiteQueryKey(id), data);
      },
      onError: () => {
        toast({ title: "Lỗi lưu website", variant: "destructive" });
      }
    }
  });

  const refineSite = useRefineSite({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Đã cập nhật website theo yêu cầu" });
        queryClient.setQueryData(getGetSiteQueryKey(id), data);
        setInstruction("");
      },
      onError: () => {
        toast({ 
          title: "Lỗi tinh chỉnh", 
          description: "Không thể thực hiện yêu cầu lúc này.",
          variant: "destructive" 
        });
      }
    }
  });

  const deleteSite = useDeleteSite({
    mutation: {
      onSuccess: () => {
        toast({ title: "Đã xóa website" });
        setLocation("/sites");
      },
      onError: () => {
        toast({ title: "Lỗi xóa", variant: "destructive" });
      }
    }
  });

  const handleSave = () => {
    if (!title.trim()) return;
    updateSite.mutate({ id, data: { title, description } });
  };

  const handleRefine = () => {
    if (!instruction.trim()) return;
    refineSite.mutate({ id, data: { instruction } });
  };

  const handleOpenNewTab = () => {
    if (!site?.html) return;
    const blob = new Blob([site.html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
  };

  const triggerDownload = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownload = async () => {
    if (!site) return;
    const slug = slugify(title || site.title || "website");

    if (files.length === 0) {
      const blob = new Blob([site.html], { type: "text/html;charset=utf-8" });
      triggerDownload(blob, `${slug}.html`);
      toast({ title: "Đã tải mã HTML" });
      return;
    }

    if (files.length === 1) {
      const file = files[0]!;
      const ext = file.path.split(".").pop() || "txt";
      const mime =
        ext === "html"
          ? "text/html"
          : ext === "css"
          ? "text/css"
          : ext === "js"
          ? "text/javascript"
          : ext === "json"
          ? "application/json"
          : "text/plain";
      const blob = new Blob([file.content], { type: `${mime};charset=utf-8` });
      triggerDownload(blob, file.path);
      toast({ title: `Đã tải ${file.path}` });
      return;
    }

    const zip = new JSZip();
    const folder = zip.folder(slug)!;
    for (const f of files) {
      folder.file(f.path, f.content);
    }
    const blob = await zip.generateAsync({ type: "blob" });
    triggerDownload(blob, `${slug}.zip`);
    toast({
      title: `Đã tải ${slug}.zip`,
      description: `Bao gồm ${files.length} file ${FORMAT_LABELS[format] ?? format}.`,
    });
  };

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4 text-primary">
          <Loader2 className="h-8 w-8 animate-spin" />
          <p className="font-medium">Đang tải website...</p>
        </div>
      </div>
    );
  }

  if (error || !site) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold">Không tìm thấy website</h2>
          <Button asChild><Link href="/sites">Quay lại danh sách</Link></Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full flex flex-col overflow-hidden bg-background">
      {/* Header */}
      <header className="h-14 border-b flex items-center justify-between px-4 shrink-0 bg-card">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild className="h-8 w-8 rounded-full">
            <Link href="/sites"><ArrowLeft className="h-4 w-4" /></Link>
          </Button>
          <div className="font-semibold">{site.title || "Chưa có tên"}</div>
          <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-wider">
            {FORMAT_LABELS[format] ?? format}
          </Badge>
          {site.industry && (
            <span className="text-xs px-2 py-1 bg-secondary text-secondary-foreground rounded-md font-medium">
              {site.industry}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                <Trash className="h-4 w-4 mr-2" /> Xóa
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Xóa website này?</AlertDialogTitle>
                <AlertDialogDescription>Hành động này không thể hoàn tác.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Hủy</AlertDialogCancel>
                <AlertDialogAction onClick={() => deleteSite.mutate({ id })} className="bg-destructive hover:bg-destructive/90">
                  Xóa
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <Button size="sm" onClick={handleSave} disabled={updateSite.isPending}>
            {updateSite.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
            Lưu thay đổi
          </Button>
        </div>
      </header>

      {/* Main Workspace */}
      <ResizablePanelGroup direction="horizontal" className="flex-1">
        {/* Left Panel - Controls */}
        <ResizablePanel defaultSize={32} minSize={26} maxSize={45} className="bg-muted/10">
          <ScrollArea className="h-full">
            <div className="p-6 space-y-8">
              
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Thông tin chung</h3>
                <div className="space-y-2">
                  <Label htmlFor="title">Tên website</Label>
                  <Input id="title" value={title} onChange={e => setTitle(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Mô tả ngắn</Label>
                  <Textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={3} />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <Zap className="h-4 w-4 text-primary" />
                  Tinh chỉnh với AI
                </h3>
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Yêu cầu AI thay đổi màu sắc, bố cục, hoặc viết lại nội dung. AI sẽ cập nhật cả bản xem trước và mã nguồn ({FORMAT_LABELS[format] ?? format}).
                  </p>
                  <Textarea 
                    placeholder="Ví dụ: Đổi tông màu thành xanh lá cây, thêm phần 'Đội ngũ' vào dưới cùng..."
                    value={instruction}
                    onChange={e => setInstruction(e.target.value)}
                    rows={4}
                  />
                  <Button 
                    className="w-full gap-2" 
                    onClick={handleRefine}
                    disabled={!instruction.trim() || refineSite.isPending}
                  >
                    {refineSite.isPending ? (
                      <><Loader2 className="h-4 w-4 animate-spin" /> Đang xử lý...</>
                    ) : (
                      <><Sparkles className="h-4 w-4" /> Yêu cầu AI sửa</>
                    )}
                  </Button>
                </div>
              </div>

              <Collapsible open={isHtmlOpen} onOpenChange={setIsHtmlOpen} className="border rounded-xl bg-card">
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" className="w-full justify-between p-4 h-auto font-semibold">
                    <span className="flex items-center gap-2">
                      <Code className="h-4 w-4" /> Mã nguồn
                      {files.length > 0 && (
                        <Badge variant="secondary" className="ml-1">{files.length} file</Badge>
                      )}
                    </span>
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="border-t bg-muted/30">
                    {files.length > 0 && (
                      <div className="flex flex-wrap gap-1 p-2 border-b bg-card/50">
                        {files.map((f) => (
                          <button
                            key={f.path}
                            type="button"
                            onClick={() => setActiveFile(f.path)}
                            className={cn(
                              "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono transition-colors",
                              activeFile === f.path
                                ? "bg-primary text-primary-foreground"
                                : "bg-muted text-muted-foreground hover:bg-muted/80",
                            )}
                          >
                            <FileText className="h-3 w-3" />
                            {f.path}
                          </button>
                        ))}
                      </div>
                    )}
                    <div className="p-3">
                      <pre className="text-xs overflow-auto max-h-[360px] p-4 rounded-md bg-zinc-950 text-zinc-50">
                        <code>{currentFile ? currentFile.content : site.html}</code>
                      </pre>
                    </div>
                  </div>
                </CollapsibleContent>
              </Collapsible>

            </div>
          </ScrollArea>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Right Panel - Preview */}
        <ResizablePanel defaultSize={68} className="bg-muted/30 flex flex-col">
          {/* Browser Chrome */}
          <div className="h-12 border-b bg-card flex items-center justify-between px-4 shrink-0 gap-3">
            <div className="flex bg-muted rounded-md p-1">
              <Button variant={viewport === "desktop" ? "secondary" : "ghost"} size="sm" className="h-7 px-2" onClick={() => setViewport("desktop")}>
                <Monitor className="h-4 w-4" />
              </Button>
              <Button variant={viewport === "tablet" ? "secondary" : "ghost"} size="sm" className="h-7 px-2" onClick={() => setViewport("tablet")}>
                <Tablet className="h-4 w-4" />
              </Button>
              <Button variant={viewport === "mobile" ? "secondary" : "ghost"} size="sm" className="h-7 px-2" onClick={() => setViewport("mobile")}>
                <Smartphone className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleDownload} className="h-8 gap-2">
                <Download className="h-3.5 w-3.5" />
                {files.length > 1 ? "Tải mã (.zip)" : "Tải mã"}
              </Button>
              <Button variant="outline" size="sm" onClick={handleOpenNewTab} className="h-8 gap-2">
                <ExternalLink className="h-3.5 w-3.5" /> Mở trong tab mới
              </Button>
            </div>
          </div>

          {/* Iframe Container */}
          <div className="flex-1 overflow-hidden flex items-center justify-center p-4 lg:p-8">
            <div 
              className={`bg-white shadow-2xl border transition-all duration-300 ease-in-out h-full mx-auto rounded-md overflow-hidden ${
                viewport === "desktop" ? "w-full max-w-[1200px]" : 
                viewport === "tablet" ? "w-[768px]" : 
                "w-[375px]"
              }`}
            >
              <iframe
                srcDoc={site.html}
                className="w-full h-full border-0 bg-white"
                sandbox="allow-scripts allow-same-origin"
                title="Website Preview"
              />
            </div>
          </div>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}

function Sparkles(props: React.SVGProps<SVGSVGElement>) {
  return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
}
