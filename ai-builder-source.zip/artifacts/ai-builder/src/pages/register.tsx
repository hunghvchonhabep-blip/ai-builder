import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Sparkles, Gift } from "lucide-react";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useRegisterMutation } from "@/hooks/use-auth";
import { ApiError } from "@workspace/api-client-react";

export default function Register() {
  const [, setLocation] = useLocation();
  const register = useRegisterMutation();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref) setReferralCode(ref);
  }, []);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    register.mutate(
      {
        data: {
          name,
          email,
          password,
          referralCode: referralCode || null,
        },
      },
      {
        onSuccess: () => setLocation("/"),
        onError: (e) => {
          const msg =
            e instanceof ApiError
              ? (e.data as { error?: string })?.error ?? e.message
              : (e as Error).message;
          setErr(msg);
        },
      },
    );
  };

  return (
    <Layout>
      <div className="flex-1 flex items-center justify-center p-6">
        <form
          onSubmit={onSubmit}
          className="w-full max-w-md space-y-5 border rounded-2xl p-8 bg-card shadow-sm"
        >
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary">
              <Sparkles className="h-6 w-6" />
            </div>
            <h1 className="text-2xl font-bold">Đăng ký miễn phí</h1>
            <div className="inline-flex items-center gap-1.5 text-sm text-yellow-700 bg-yellow-50 dark:text-yellow-400 dark:bg-yellow-500/10 rounded-full px-3 py-1">
              <Gift className="h-4 w-4" /> Tặng 100 điểm khi đăng ký
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="name">Họ và tên</Label>
            <Input
              id="name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              data-testid="input-name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              data-testid="input-email"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Mật khẩu (tối thiểu 6 ký tự)</Label>
            <Input
              id="password"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              data-testid="input-password"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="referral">Mã giới thiệu (tùy chọn)</Label>
            <Input
              id="referral"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
              placeholder="Nhập mã từ người giới thiệu"
              data-testid="input-referral"
            />
          </div>
          {err && (
            <div className="text-sm text-destructive bg-destructive/10 rounded-md px-3 py-2">
              {err}
            </div>
          )}
          <Button
            type="submit"
            className="w-full"
            disabled={register.isPending}
            data-testid="button-submit-register"
          >
            {register.isPending ? "Đang xử lý..." : "Tạo tài khoản"}
          </Button>
          <p className="text-sm text-center text-muted-foreground">
            Đã có tài khoản?{" "}
            <Link href="/login" className="text-primary font-medium hover:underline">
              Đăng nhập
            </Link>
          </p>
        </form>
      </div>
    </Layout>
  );
}
