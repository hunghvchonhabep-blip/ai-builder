import { useState } from "react";
import { Coins, CheckCircle2, Clock, XCircle, Sparkles } from "lucide-react";
import { Layout } from "@/components/layout";
import { AuthGate } from "@/components/auth-gate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {
  useCreateTopup,
  useGetPricing,
  useListMyTopups,
  type PricingTier,
  type CreateTopupBodyMethod,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const METHODS: { id: CreateTopupBodyMethod; name: string; hint: string }[] = [
  { id: "vnpay", name: "VNPay", hint: "Thẻ ATM nội địa, Internet Banking" },
  { id: "momo", name: "Momo", hint: "Ví điện tử Momo" },
  { id: "banktransfer", name: "Chuyển khoản ngân hàng", hint: "Chuyển khoản thủ công" },
];

function formatVnd(n: number) {
  return n.toLocaleString("vi-VN") + "đ";
}

function StatusBadge({ status }: { status: string }) {
  if (status === "approved")
    return (
      <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
        <CheckCircle2 className="h-3 w-3 mr-1" /> Đã duyệt
      </Badge>
    );
  if (status === "rejected")
    return (
      <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100">
        <XCircle className="h-3 w-3 mr-1" /> Từ chối
      </Badge>
    );
  return (
    <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
      <Clock className="h-3 w-3 mr-1" /> Đang chờ duyệt
    </Badge>
  );
}

function Inner() {
  const { me } = useAuth();
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data: pricing } = useGetPricing();
  const { data: topups = [], refetch } = useListMyTopups();
  const createTopup = useCreateTopup();

  const [selectedTier, setSelectedTier] = useState<PricingTier | null>(null);
  const [method, setMethod] = useState<CreateTopupBodyMethod>("vnpay");
  const [proofNote, setProofNote] = useState("");

  const handleSubmit = async () => {
    if (!selectedTier) return;
    try {
      await createTopup.mutateAsync({
        data: {
          amountVnd: selectedTier.amountVnd,
          method,
          proofNote: proofNote || null,
        },
      });
      toast({
        title: "Đã gửi yêu cầu nạp điểm",
        description: "Quản trị viên sẽ duyệt yêu cầu và cộng điểm cho bạn sớm.",
      });
      setSelectedTier(null);
      setProofNote("");
      void refetch();
      void qc.invalidateQueries();
    } catch (e) {
      toast({
        title: "Lỗi",
        description: (e as Error).message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-5xl space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Nạp điểm</h1>
          <p className="text-sm text-muted-foreground">
            Bạn đang có{" "}
            <span className="font-semibold text-primary">{me?.points}</span> điểm.
            {pricing && (
              <>
                {" "}Mỗi lần tạo dự án trừ <b>{pricing.generateCost}</b> điểm, mỗi lần
                tinh chỉnh trừ <b>{pricing.refineCost}</b> điểm.
              </>
            )}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {(pricing?.tiers ?? []).map((tier) => {
          const selected = selectedTier?.amountVnd === tier.amountVnd;
          return (
            <button
              key={tier.amountVnd}
              type="button"
              onClick={() => setSelectedTier(tier)}
              className={`text-left border rounded-2xl p-5 bg-card transition-all hover:shadow-md ${
                selected ? "border-primary ring-2 ring-primary/30" : ""
              }`}
              data-testid={`tier-${tier.amountVnd}`}
            >
              <div className="text-sm text-muted-foreground">{tier.label}</div>
              <div className="text-2xl font-bold mt-1">{formatVnd(tier.amountVnd)}</div>
              <div className="flex items-center gap-1.5 mt-2 text-primary">
                <Coins className="h-4 w-4 text-yellow-500" />
                <span className="font-semibold">{tier.points} điểm</span>
                {tier.bonusPct > 0 && (
                  <Badge variant="secondary" className="ml-1">
                    +{tier.bonusPct}%
                  </Badge>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {selectedTier && (
        <div className="border rounded-2xl p-6 bg-card space-y-4">
          <h2 className="font-semibold flex items-center gap-2">
            <Sparkles className="h-4 w-4" /> Hoàn tất yêu cầu nạp{" "}
            {formatVnd(selectedTier.amountVnd)} ={" "}
            <span className="text-primary">{selectedTier.points} điểm</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {METHODS.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id)}
                className={`text-left border rounded-xl p-4 transition ${
                  method === m.id
                    ? "border-primary bg-primary/5"
                    : "hover:bg-accent/30"
                }`}
                data-testid={`method-${m.id}`}
              >
                <div className="font-semibold">{m.name}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{m.hint}</div>
              </button>
            ))}
          </div>
          <div className="bg-amber-50 border border-amber-200 dark:bg-amber-500/10 dark:border-amber-500/30 rounded-xl p-4 text-sm">
            <p className="font-medium mb-1">Hướng dẫn thanh toán</p>
            <p className="text-muted-foreground">
              Tích hợp cổng thanh toán tự động đang được hoàn thiện. Vui lòng chuyển{" "}
              <b>{formatVnd(selectedTier.amountVnd)}</b> qua{" "}
              {METHODS.find((m) => m.id === method)?.name} đến tài khoản của shop và ghi
              chú nội dung là email của bạn. Sau khi quản trị viên xác nhận, điểm sẽ
              được cộng tự động.
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="proof">Ghi chú (mã giao dịch, thời gian chuyển...)</Label>
            <Input
              id="proof"
              value={proofNote}
              onChange={(e) => setProofNote(e.target.value)}
              placeholder="VD: Đã chuyển 100k qua Momo, mã GD 123456"
              data-testid="input-proof"
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setSelectedTier(null)}>
              Hủy
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={createTopup.isPending}
              data-testid="button-submit-topup"
            >
              {createTopup.isPending ? "Đang gửi..." : "Gửi yêu cầu nạp"}
            </Button>
          </div>
        </div>
      )}

      <div className="border rounded-2xl bg-card overflow-hidden">
        <div className="px-5 py-4 border-b">
          <h2 className="font-semibold">Lịch sử yêu cầu nạp</h2>
        </div>
        {topups.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">
            Chưa có yêu cầu nạp nào.
          </div>
        ) : (
          <ul className="divide-y">
            {topups.map((t) => (
              <li
                key={t.id}
                className="flex items-center justify-between px-5 py-3"
                data-testid={`topup-${t.id}`}
              >
                <div>
                  <div className="font-medium">
                    {formatVnd(t.amountVnd)} →{" "}
                    <span className="text-primary">{t.points} điểm</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {t.method.toUpperCase()} •{" "}
                    {new Date(t.createdAt).toLocaleString("vi-VN")}
                    {t.adminNote && ` • ${t.adminNote}`}
                  </div>
                </div>
                <StatusBadge status={t.status} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default function TopupPage() {
  return (
    <Layout>
      <AuthGate>
        <Inner />
      </AuthGate>
    </Layout>
  );
}
