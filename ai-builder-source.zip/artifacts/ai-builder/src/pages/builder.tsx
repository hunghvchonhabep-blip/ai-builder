import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import {
  DndContext,
  PointerSensor,
  useSensor,
  useSensors,
  closestCenter,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useMutation } from "@tanstack/react-query";
import {
  ArrowLeft,
  Eye,
  GripVertical,
  Loader2,
  Monitor,
  Plus,
  Save,
  Smartphone,
  Trash2,
  X,
} from "lucide-react";
import { useCreateSite, ApiError } from "@workspace/api-client-react";

import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {
  MODULES,
  MODULE_BY_KEY,
  buildHtml,
  defaultProps,
  type BlockInstance,
  type ModuleField,
} from "@/lib/builder-modules";

const uid = () => Math.random().toString(36).slice(2, 10);

function SortableBlock({
  block,
  selected,
  onSelect,
  onDelete,
}: {
  block: BlockInstance;
  selected: boolean;
  onSelect: () => void;
  onDelete: () => void;
}) {
  const mod = MODULE_BY_KEY[block.moduleKey];
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: block.id,
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };
  if (!mod) return null;
  return (
    <div
      ref={setNodeRef}
      style={style}
      onClick={onSelect}
      className={`group relative border-2 rounded-lg overflow-hidden bg-white cursor-pointer transition ${
        selected ? "border-indigo-500 shadow-lg" : "border-transparent hover:border-slate-300"
      }`}
    >
      <div className="absolute top-2 left-2 z-10 flex gap-1 opacity-0 group-hover:opacity-100 transition">
        <button
          {...attributes}
          {...listeners}
          onClick={(e) => e.stopPropagation()}
          className="bg-white/90 backdrop-blur p-1.5 rounded-md shadow border border-slate-200 cursor-grab active:cursor-grabbing"
          aria-label="Kéo để sắp xếp"
        >
          <GripVertical className="h-4 w-4 text-slate-600" />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          className="bg-white/90 backdrop-blur p-1.5 rounded-md shadow border border-slate-200 hover:bg-red-50"
          aria-label="Xóa"
        >
          <Trash2 className="h-4 w-4 text-red-600" />
        </button>
      </div>
      <div
        className="pointer-events-none"
        dangerouslySetInnerHTML={{ __html: mod.render(block.props) }}
      />
    </div>
  );
}

function FieldEditor({
  field,
  value,
  onChange,
}: {
  field: ModuleField;
  value: unknown;
  onChange: (v: unknown) => void;
}) {
  if (field.type === "textarea") {
    return (
      <Textarea
        value={String(value ?? "")}
        onChange={(e) => onChange(e.target.value)}
        rows={3}
        className="text-sm"
      />
    );
  }
  if (field.type === "list") {
    const items = Array.isArray(value) ? (value as Array<Record<string, string>>) : [];
    const itemFields = field.itemFields ?? [];
    return (
      <div className="space-y-2">
        {items.map((item, idx) => (
          <div key={idx} className="border border-slate-200 rounded-lg p-3 space-y-2 bg-slate-50/50">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Mục #{idx + 1}</span>
              <button
                onClick={() => {
                  const next = items.slice();
                  next.splice(idx, 1);
                  onChange(next);
                }}
                className="text-red-600 hover:bg-red-50 p-1 rounded"
                aria-label="Xóa mục"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
            {itemFields.map((sub) => (
              <div key={sub.key} className="space-y-1">
                <Label className="text-xs text-slate-600">{sub.label}</Label>
                {sub.type === "textarea" ? (
                  <Textarea
                    value={String(item[sub.key] ?? "")}
                    onChange={(e) => {
                      const next = items.slice();
                      next[idx] = { ...item, [sub.key]: e.target.value };
                      onChange(next);
                    }}
                    rows={2}
                    className="text-sm"
                  />
                ) : (
                  <Input
                    value={String(item[sub.key] ?? "")}
                    onChange={(e) => {
                      const next = items.slice();
                      next[idx] = { ...item, [sub.key]: e.target.value };
                      onChange(next);
                    }}
                    className="h-8 text-sm"
                  />
                )}
              </div>
            ))}
          </div>
        ))}
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          onClick={() => {
            const blank: Record<string, string> = {};
            for (const sub of itemFields) blank[sub.key] = sub.default;
            onChange([...items, blank]);
          }}
        >
          <Plus className="h-3.5 w-3.5 mr-1" /> Thêm mục
        </Button>
      </div>
    );
  }
  return (
    <Input
      value={String(value ?? "")}
      onChange={(e) => onChange(e.target.value)}
      className="text-sm"
    />
  );
}

export default function Builder() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  const [blocks, setBlocks] = useState<BlockInstance[]>(() => [
    { id: uid(), moduleKey: "header", props: defaultProps(MODULE_BY_KEY.header) },
    { id: uid(), moduleKey: "hero-center", props: defaultProps(MODULE_BY_KEY["hero-center"]) },
    { id: uid(), moduleKey: "features-3", props: defaultProps(MODULE_BY_KEY["features-3"]) },
    { id: uid(), moduleKey: "cta", props: defaultProps(MODULE_BY_KEY.cta) },
    { id: uid(), moduleKey: "footer", props: defaultProps(MODULE_BY_KEY.footer) },
  ]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const [pageTitle, setPageTitle] = useState("Website mới của tôi");
  const [previewOpen, setPreviewOpen] = useState(false);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const selected = blocks.find((b) => b.id === selectedId) ?? null;
  const selectedMod = selected ? MODULE_BY_KEY[selected.moduleKey] : null;

  const categories = useMemo(() => {
    const map = new Map<string, typeof MODULES>();
    for (const m of MODULES) {
      const arr = map.get(m.category) ?? [];
      arr.push(m);
      map.set(m.category, arr);
    }
    return Array.from(map.entries());
  }, []);

  const html = useMemo(() => buildHtml(blocks, pageTitle), [blocks, pageTitle]);

  const createSite = useCreateSite();
  const saveMut = useMutation({
    mutationFn: async () => {
      return createSite.mutateAsync({
        data: {
          title: pageTitle,
          description: `Tạo bằng kéo-thả • ${blocks.length} khối`,
          prompt: `[Builder] ${blocks.map((b) => b.moduleKey).join(", ")}`,
          html,
        },
      });
    },
    onSuccess: (site) => {
      toast({ title: "Đã lưu", description: "Website đã được lưu vào dự án của bạn." });
      setLocation(`/sites/${site.id}`);
    },
    onError: (err) => {
      if (err instanceof ApiError && err.status === 401) {
        toast({ title: "Cần đăng nhập", variant: "destructive" });
        setLocation("/login");
        return;
      }
      toast({ title: "Lỗi khi lưu", description: String(err), variant: "destructive" });
    },
  });

  const handleAdd = (moduleKey: string) => {
    const mod = MODULE_BY_KEY[moduleKey];
    if (!mod) return;
    const block: BlockInstance = { id: uid(), moduleKey, props: defaultProps(mod) };
    setBlocks((b) => [...b, block]);
    setSelectedId(block.id);
  };

  const handleDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    setBlocks((items) => {
      const oldIdx = items.findIndex((i) => i.id === active.id);
      const newIdx = items.findIndex((i) => i.id === over.id);
      return arrayMove(items, oldIdx, newIdx);
    });
  };

  const updateProp = (key: string, value: unknown) => {
    if (!selected) return;
    setBlocks((bs) =>
      bs.map((b) => (b.id === selected.id ? { ...b, props: { ...b.props, [key]: value } } : b)),
    );
  };

  return (
    <Layout>
      <div className="flex flex-col h-[calc(100vh-4rem)] -mt-6">
        <div className="flex items-center justify-between border-b bg-white px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => setLocation("/")}>
              <ArrowLeft className="h-4 w-4 mr-1" /> Trang chủ
            </Button>
            <Input
              value={pageTitle}
              onChange={(e) => setPageTitle(e.target.value)}
              className="h-9 w-72 font-medium"
            />
          </div>
          <div className="flex items-center gap-2">
            <div className="flex border rounded-md p-0.5">
              <button
                onClick={() => setDevice("desktop")}
                className={`p-1.5 rounded ${device === "desktop" ? "bg-slate-100" : ""}`}
                aria-label="Desktop"
              >
                <Monitor className="h-4 w-4" />
              </button>
              <button
                onClick={() => setDevice("mobile")}
                className={`p-1.5 rounded ${device === "mobile" ? "bg-slate-100" : ""}`}
                aria-label="Mobile"
              >
                <Smartphone className="h-4 w-4" />
              </button>
            </div>
            <Button variant="outline" size="sm" onClick={() => setPreviewOpen(true)}>
              <Eye className="h-4 w-4 mr-1" /> Xem trước
            </Button>
            <Button
              size="sm"
              onClick={() => {
                if (!user) {
                  setLocation("/login");
                  return;
                }
                saveMut.mutate();
              }}
              disabled={saveMut.isPending || blocks.length === 0}
            >
              {saveMut.isPending ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-1" />
              )}
              Lưu dự án
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-[260px_1fr_320px] flex-1 overflow-hidden">
          {/* Module palette */}
          <aside className="border-r bg-slate-50 overflow-y-auto p-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2 px-1">
              Modules
            </h3>
            {categories.map(([cat, mods]) => (
              <div key={cat} className="mb-4">
                <div className="text-xs font-medium text-slate-600 px-1 mb-1.5">{cat}</div>
                <div className="space-y-1">
                  {mods.map((m) => (
                    <button
                      key={m.key}
                      onClick={() => handleAdd(m.key)}
                      className="w-full text-left px-3 py-2 rounded-md bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-sm transition group"
                    >
                      <div className="text-sm font-medium text-slate-900 flex items-center justify-between">
                        {m.label}
                        <Plus className="h-3.5 w-3.5 text-slate-400 group-hover:text-indigo-600" />
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">{m.description}</div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </aside>

          {/* Canvas */}
          <main className="overflow-y-auto bg-slate-100 p-6" onClick={() => setSelectedId(null)}>
            <div
              className={`mx-auto bg-white shadow-2xl rounded-lg overflow-hidden transition-all ${
                device === "mobile" ? "max-w-sm" : "max-w-5xl"
              }`}
              onClick={(e) => e.stopPropagation()}
            >
              {blocks.length === 0 ? (
                <div className="p-20 text-center text-slate-500">
                  <p className="mb-2 font-medium">Chưa có khối nào</p>
                  <p className="text-sm">Chọn module ở bên trái để thêm vào trang</p>
                </div>
              ) : (
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
                    <div className="space-y-1">
                      {blocks.map((b) => (
                        <SortableBlock
                          key={b.id}
                          block={b}
                          selected={selectedId === b.id}
                          onSelect={() => setSelectedId(b.id)}
                          onDelete={() => {
                            setBlocks((bs) => bs.filter((x) => x.id !== b.id));
                            if (selectedId === b.id) setSelectedId(null);
                          }}
                        />
                      ))}
                    </div>
                  </SortableContext>
                </DndContext>
              )}
            </div>
          </main>

          {/* Inspector */}
          <aside className="border-l bg-white overflow-y-auto">
            {selected && selectedMod ? (
              <div className="p-4 space-y-4">
                <div>
                  <div className="text-xs uppercase tracking-wider text-slate-500">Chỉnh sửa</div>
                  <div className="text-base font-semibold text-slate-900">{selectedMod.label}</div>
                </div>
                {selectedMod.fields.map((f) => (
                  <div key={f.key} className="space-y-1.5">
                    <Label className="text-xs font-medium text-slate-700">{f.label}</Label>
                    <FieldEditor
                      field={f}
                      value={selected.props[f.key]}
                      onChange={(v) => updateProp(f.key, v)}
                    />
                  </div>
                ))}
                <Card className="p-3 bg-slate-50 border-dashed">
                  <p className="text-xs text-slate-600">
                    Mẹo: Click vào khối ngoài cùng để chọn, kéo biểu tượng để sắp xếp lại.
                  </p>
                </Card>
              </div>
            ) : (
              <div className="p-6 text-sm text-slate-500 text-center">
                Chọn một khối để chỉnh sửa nội dung.
              </div>
            )}
          </aside>
        </div>

        {previewOpen && (
          <div className="fixed inset-0 z-50 bg-black/70 flex flex-col">
            <div className="bg-white border-b px-4 py-2 flex items-center justify-between">
              <div className="font-medium">Xem trước: {pageTitle}</div>
              <Button variant="ghost" size="sm" onClick={() => setPreviewOpen(false)}>
                <X className="h-4 w-4 mr-1" /> Đóng
              </Button>
            </div>
            <iframe srcDoc={html} className="flex-1 bg-white" title="preview" />
          </div>
        )}
      </div>
    </Layout>
  );
}
