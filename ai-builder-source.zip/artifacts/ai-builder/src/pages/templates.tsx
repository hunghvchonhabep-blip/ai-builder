import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Sparkles } from "lucide-react";
import { Layout as AppLayout } from "@/components/layout";
import { TemplateCard } from "@/components/template-card";
import { Input } from "@/components/ui/input";
import { useListTemplates } from "@workspace/api-client-react";

export default function Templates() {
  const [search, setSearch] = useState("");
  const { data: templates, isLoading } = useListTemplates();

  const filteredTemplates = templates?.filter(t => 
    t.title.toLowerCase().includes(search.toLowerCase()) || 
    t.description.toLowerCase().includes(search.toLowerCase()) ||
    t.industry.toLowerCase().includes(search.toLowerCase())
  ) || [];

  return (
    <AppLayout>
      <div className="container mx-auto px-4 py-12 max-w-7xl">
        <div className="max-w-2xl mx-auto text-center space-y-4 mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-full mb-4">
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-foreground">Thư viện cảm hứng</h1>
          <p className="text-lg text-muted-foreground">
            Bắt đầu nhanh với các ý tưởng mẫu. Chọn một mẫu bạn thích, chúng tôi sẽ điền sẵn prompt cho bạn.
          </p>
        </div>

        <div className="max-w-md mx-auto relative mb-12">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Tìm kiếm mẫu, lĩnh vực..."
            className="pl-12 h-12 text-base rounded-full bg-card"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-[250px] rounded-xl bg-muted animate-pulse" />
            ))}
          </div>
        ) : filteredTemplates.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredTemplates.map((template, i) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: Math.min(i * 0.05, 0.4) }}
              >
                <TemplateCard template={template} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-muted-foreground text-lg">Không tìm thấy mẫu nào phù hợp với tìm kiếm của bạn.</p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
