import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Home from "@/pages/home";
import Sites from "@/pages/sites";
import SiteEditor from "@/pages/site-editor";
import Templates from "@/pages/templates";
import Builder from "@/pages/builder";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Account from "@/pages/account";
import Topup from "@/pages/topup";
import Affiliate from "@/pages/affiliate";
import Admin from "@/pages/admin";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/sites" component={Sites} />
      <Route path="/sites/:id" component={SiteEditor} />
      <Route path="/templates" component={Templates} />
      <Route path="/builder" component={Builder} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/account" component={Account} />
      <Route path="/account/topup" component={Topup} />
      <Route path="/account/affiliate" component={Affiliate} />
      <Route path="/admin" component={Admin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
