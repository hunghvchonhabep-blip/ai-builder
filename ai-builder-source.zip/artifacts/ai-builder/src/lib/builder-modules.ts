export type FieldType = "text" | "textarea" | "image" | "color" | "list";

export interface ModuleField {
  key: string;
  label: string;
  type: FieldType;
  default: string;
  itemFields?: ModuleField[];
}

export interface ModuleDef {
  key: string;
  category: string;
  label: string;
  description: string;
  icon: string;
  fields: ModuleField[];
  render: (props: Record<string, unknown>) => string;
}

const esc = (v: unknown) =>
  String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const list = (v: unknown): Array<Record<string, string>> =>
  Array.isArray(v) ? (v as Array<Record<string, string>>) : [];

export const MODULES: ModuleDef[] = [
  {
    key: "header",
    category: "Đầu trang",
    label: "Thanh điều hướng",
    description: "Logo + menu + nút CTA",
    icon: "Menu",
    fields: [
      { key: "brand", label: "Tên thương hiệu", type: "text", default: "Thương hiệu" },
      { key: "menu", label: "Menu (ngăn cách bởi |)", type: "text", default: "Trang chủ|Dịch vụ|Về chúng tôi|Liên hệ" },
      { key: "ctaText", label: "Nút CTA", type: "text", default: "Liên hệ ngay" },
    ],
    render: (p) => {
      const items = String(p.menu || "")
        .split("|")
        .map((s) => s.trim())
        .filter(Boolean);
      return `<header class="sticky top-0 z-50 bg-white/90 backdrop-blur border-b border-slate-200">
  <div class="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
    <a href="#" class="font-bold text-xl text-slate-900">${esc(p.brand)}</a>
    <nav class="hidden md:flex gap-7 text-sm text-slate-600">
      ${items.map((i) => `<a href="#" class="hover:text-slate-900">${esc(i)}</a>`).join("")}
    </nav>
    <a href="#" class="bg-slate-900 text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-slate-700">${esc(p.ctaText)}</a>
  </div>
</header>`;
    },
  },
  {
    key: "hero-center",
    category: "Hero",
    label: "Hero – căn giữa",
    description: "Tiêu đề lớn ở giữa với 2 nút",
    icon: "Sparkles",
    fields: [
      { key: "eyebrow", label: "Nhãn nhỏ", type: "text", default: "Mới ra mắt" },
      { key: "title", label: "Tiêu đề", type: "text", default: "Giải pháp tuyệt vời cho doanh nghiệp" },
      { key: "subtitle", label: "Mô tả", type: "textarea", default: "Chúng tôi giúp bạn xây dựng thương hiệu, tăng doanh số và phát triển bền vững." },
      { key: "primaryText", label: "Nút chính", type: "text", default: "Bắt đầu ngay" },
      { key: "secondaryText", label: "Nút phụ", type: "text", default: "Tìm hiểu thêm" },
    ],
    render: (p) => `<section class="bg-gradient-to-b from-indigo-50 via-white to-white">
  <div class="max-w-4xl mx-auto px-6 py-24 text-center">
    <span class="inline-block bg-indigo-100 text-indigo-700 px-4 py-1.5 rounded-full text-xs font-medium mb-6">${esc(p.eyebrow)}</span>
    <h1 class="text-5xl md:text-6xl font-bold text-slate-900 leading-tight mb-6">${esc(p.title)}</h1>
    <p class="text-lg text-slate-600 max-w-2xl mx-auto mb-10">${esc(p.subtitle)}</p>
    <div class="flex gap-4 justify-center flex-wrap">
      <a href="#" class="bg-indigo-600 text-white px-7 py-3 rounded-full font-medium hover:bg-indigo-700">${esc(p.primaryText)}</a>
      <a href="#" class="bg-white border border-slate-300 text-slate-900 px-7 py-3 rounded-full font-medium hover:bg-slate-50">${esc(p.secondaryText)}</a>
    </div>
  </div>
</section>`,
  },
  {
    key: "hero-split",
    category: "Hero",
    label: "Hero – chia 2 cột",
    description: "Văn bản bên trái, ảnh bên phải",
    icon: "LayoutPanelLeft",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Phát triển doanh nghiệp với chúng tôi" },
      { key: "subtitle", label: "Mô tả", type: "textarea", default: "Đội ngũ chuyên gia hơn 10 năm kinh nghiệm, giúp khách hàng đạt mục tiêu nhanh chóng." },
      { key: "primaryText", label: "Nút chính", type: "text", default: "Đăng ký ngay" },
      { key: "image", label: "URL ảnh", type: "image", default: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=900" },
    ],
    render: (p) => `<section class="bg-white">
  <div class="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-12 items-center">
    <div>
      <h1 class="text-4xl md:text-5xl font-bold text-slate-900 leading-tight mb-5">${esc(p.title)}</h1>
      <p class="text-lg text-slate-600 mb-8">${esc(p.subtitle)}</p>
      <a href="#" class="inline-block bg-slate-900 text-white px-7 py-3 rounded-full font-medium hover:bg-slate-700">${esc(p.primaryText)}</a>
    </div>
    <img src="${esc(p.image)}" alt="" class="rounded-2xl shadow-xl w-full" />
  </div>
</section>`,
  },
  {
    key: "features-3",
    category: "Tính năng",
    label: "3 tính năng nổi bật",
    description: "Lưới 3 cột với icon",
    icon: "LayoutGrid",
    fields: [
      { key: "title", label: "Tiêu đề khối", type: "text", default: "Vì sao chọn chúng tôi" },
      {
        key: "items",
        label: "Mục",
        type: "list",
        default: JSON.stringify([
          { icon: "⚡", title: "Nhanh chóng", desc: "Triển khai trong vài ngày" },
          { icon: "🎯", title: "Chính xác", desc: "Hiểu rõ nhu cầu của bạn" },
          { icon: "💎", title: "Chất lượng", desc: "Cam kết hoàn tiền nếu không hài lòng" },
        ]),
        itemFields: [
          { key: "icon", label: "Icon (emoji)", type: "text", default: "✨" },
          { key: "title", label: "Tiêu đề", type: "text", default: "" },
          { key: "desc", label: "Mô tả", type: "textarea", default: "" },
        ],
      },
    ],
    render: (p) => {
      const items = list(p.items);
      return `<section class="bg-slate-50">
  <div class="max-w-6xl mx-auto px-6 py-20">
    <h2 class="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-14">${esc(p.title)}</h2>
    <div class="grid md:grid-cols-3 gap-8">
      ${items
        .map(
          (it) => `<div class="bg-white p-8 rounded-2xl border border-slate-200">
        <div class="text-4xl mb-4">${esc(it.icon)}</div>
        <h3 class="text-xl font-semibold text-slate-900 mb-2">${esc(it.title)}</h3>
        <p class="text-slate-600">${esc(it.desc)}</p>
      </div>`,
        )
        .join("")}
    </div>
  </div>
</section>`;
    },
  },
  {
    key: "about",
    category: "Giới thiệu",
    label: "Giới thiệu + ảnh",
    description: "Văn bản dài kèm ảnh minh họa",
    icon: "BookOpen",
    fields: [
      { key: "eyebrow", label: "Nhãn nhỏ", type: "text", default: "Về chúng tôi" },
      { key: "title", label: "Tiêu đề", type: "text", default: "Câu chuyện của chúng tôi" },
      { key: "body", label: "Nội dung", type: "textarea", default: "Thành lập từ năm 2015, chúng tôi đã đồng hành cùng hơn 500 doanh nghiệp Việt Nam trong hành trình chuyển đổi số. Sứ mệnh của chúng tôi là mang công nghệ đến gần hơn với mọi người." },
      { key: "image", label: "URL ảnh", type: "image", default: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900" },
    ],
    render: (p) => `<section class="bg-white">
  <div class="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-12 items-center">
    <img src="${esc(p.image)}" alt="" class="rounded-2xl w-full" />
    <div>
      <span class="text-indigo-600 text-sm font-semibold uppercase tracking-wider">${esc(p.eyebrow)}</span>
      <h2 class="text-3xl md:text-4xl font-bold text-slate-900 mt-2 mb-5">${esc(p.title)}</h2>
      <p class="text-lg text-slate-600 leading-relaxed whitespace-pre-line">${esc(p.body)}</p>
    </div>
  </div>
</section>`,
  },
  {
    key: "services",
    category: "Dịch vụ",
    label: "Lưới dịch vụ",
    description: "4 dịch vụ kèm icon",
    icon: "Briefcase",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Dịch vụ của chúng tôi" },
      {
        key: "items",
        label: "Dịch vụ",
        type: "list",
        default: JSON.stringify([
          { icon: "💻", title: "Thiết kế web", desc: "Website chuyên nghiệp, chuẩn SEO" },
          { icon: "📱", title: "App mobile", desc: "Ứng dụng iOS và Android" },
          { icon: "📈", title: "Marketing", desc: "Chạy quảng cáo Facebook & Google" },
          { icon: "🎨", title: "Branding", desc: "Bộ nhận diện thương hiệu" },
        ]),
        itemFields: [
          { key: "icon", label: "Icon", type: "text", default: "✨" },
          { key: "title", label: "Tên dịch vụ", type: "text", default: "" },
          { key: "desc", label: "Mô tả", type: "textarea", default: "" },
        ],
      },
    ],
    render: (p) => {
      const items = list(p.items);
      return `<section class="bg-white">
  <div class="max-w-6xl mx-auto px-6 py-20">
    <h2 class="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-14">${esc(p.title)}</h2>
    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
      ${items
        .map(
          (it) => `<div class="border border-slate-200 p-6 rounded-2xl hover:shadow-lg transition">
        <div class="w-12 h-12 bg-indigo-100 text-indigo-700 rounded-xl flex items-center justify-center text-2xl mb-4">${esc(it.icon)}</div>
        <h3 class="font-semibold text-slate-900 mb-2">${esc(it.title)}</h3>
        <p class="text-sm text-slate-600">${esc(it.desc)}</p>
      </div>`,
        )
        .join("")}
    </div>
  </div>
</section>`;
    },
  },
  {
    key: "pricing",
    category: "Bảng giá",
    label: "Bảng giá 3 gói",
    description: "Cơ bản / Phổ biến / Pro",
    icon: "Tag",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Bảng giá" },
      {
        key: "items",
        label: "Gói",
        type: "list",
        default: JSON.stringify([
          { name: "Cơ bản", price: "199K", period: "/tháng", features: "10 dự án|Hỗ trợ email|1 GB lưu trữ", cta: "Bắt đầu", highlight: "" },
          { name: "Phổ biến", price: "499K", period: "/tháng", features: "Không giới hạn dự án|Hỗ trợ ưu tiên|10 GB lưu trữ|Tích hợp API", cta: "Đăng ký", highlight: "1" },
          { name: "Doanh nghiệp", price: "1.5M", period: "/tháng", features: "Mọi tính năng Pro|Hỗ trợ 24/7|100 GB|Domain riêng", cta: "Liên hệ", highlight: "" },
        ]),
        itemFields: [
          { key: "name", label: "Tên gói", type: "text", default: "" },
          { key: "price", label: "Giá", type: "text", default: "" },
          { key: "period", label: "Đơn vị", type: "text", default: "/tháng" },
          { key: "features", label: "Tính năng (|)", type: "textarea", default: "" },
          { key: "cta", label: "Nút", type: "text", default: "Chọn gói" },
          { key: "highlight", label: "Nổi bật? (1/0)", type: "text", default: "" },
        ],
      },
    ],
    render: (p) => {
      const items = list(p.items);
      return `<section class="bg-slate-50">
  <div class="max-w-6xl mx-auto px-6 py-20">
    <h2 class="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-14">${esc(p.title)}</h2>
    <div class="grid md:grid-cols-3 gap-6">
      ${items
        .map((it) => {
          const hi = String(it.highlight || "") === "1";
          const features = String(it.features || "")
            .split("|")
            .map((f) => f.trim())
            .filter(Boolean);
          return `<div class="${hi ? "bg-slate-900 text-white ring-4 ring-indigo-500/30 scale-105" : "bg-white text-slate-900"} p-8 rounded-2xl border border-slate-200">
        <h3 class="text-lg font-semibold mb-1">${esc(it.name)}</h3>
        <div class="mb-6"><span class="text-4xl font-bold">${esc(it.price)}</span><span class="${hi ? "text-slate-300" : "text-slate-500"}">${esc(it.period)}</span></div>
        <ul class="space-y-3 mb-8 text-sm">
          ${features.map((f) => `<li class="flex gap-2"><span>✓</span><span>${esc(f)}</span></li>`).join("")}
        </ul>
        <a href="#" class="${hi ? "bg-white text-slate-900" : "bg-slate-900 text-white"} block text-center py-3 rounded-full font-medium">${esc(it.cta)}</a>
      </div>`;
        })
        .join("")}
    </div>
  </div>
</section>`;
    },
  },
  {
    key: "testimonials",
    category: "Đánh giá",
    label: "Đánh giá khách hàng",
    description: "3 lời chứng thực",
    icon: "MessageSquareQuote",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Khách hàng nói gì" },
      {
        key: "items",
        label: "Đánh giá",
        type: "list",
        default: JSON.stringify([
          { name: "Anh Minh", role: "CEO Công ty ABC", quote: "Dịch vụ rất chuyên nghiệp, kết quả vượt mong đợi.", avatar: "https://i.pravatar.cc/100?img=12" },
          { name: "Chị Lan", role: "Giám đốc XYZ", quote: "Đội ngũ tận tâm, hỗ trợ nhanh chóng mọi lúc.", avatar: "https://i.pravatar.cc/100?img=44" },
          { name: "Anh Tuấn", role: "Founder Startup", quote: "Nhờ họ mà công ty tôi tăng trưởng 200% trong 6 tháng.", avatar: "https://i.pravatar.cc/100?img=33" },
        ]),
        itemFields: [
          { key: "name", label: "Tên", type: "text", default: "" },
          { key: "role", label: "Chức vụ", type: "text", default: "" },
          { key: "quote", label: "Lời chứng thực", type: "textarea", default: "" },
          { key: "avatar", label: "URL avatar", type: "image", default: "" },
        ],
      },
    ],
    render: (p) => {
      const items = list(p.items);
      return `<section class="bg-white">
  <div class="max-w-6xl mx-auto px-6 py-20">
    <h2 class="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-14">${esc(p.title)}</h2>
    <div class="grid md:grid-cols-3 gap-6">
      ${items
        .map(
          (it) => `<figure class="bg-slate-50 p-8 rounded-2xl">
        <blockquote class="text-slate-700 italic mb-6">"${esc(it.quote)}"</blockquote>
        <figcaption class="flex items-center gap-3">
          <img src="${esc(it.avatar)}" class="w-12 h-12 rounded-full object-cover" alt="" />
          <div>
            <div class="font-semibold text-slate-900">${esc(it.name)}</div>
            <div class="text-sm text-slate-500">${esc(it.role)}</div>
          </div>
        </figcaption>
      </figure>`,
        )
        .join("")}
    </div>
  </div>
</section>`;
    },
  },
  {
    key: "stats",
    category: "Số liệu",
    label: "Thống kê 4 cột",
    description: "Số liệu ấn tượng",
    icon: "BarChart3",
    fields: [
      {
        key: "items",
        label: "Số liệu",
        type: "list",
        default: JSON.stringify([
          { value: "500+", label: "Khách hàng" },
          { value: "10", label: "Năm kinh nghiệm" },
          { value: "98%", label: "Hài lòng" },
          { value: "24/7", label: "Hỗ trợ" },
        ]),
        itemFields: [
          { key: "value", label: "Giá trị", type: "text", default: "" },
          { key: "label", label: "Nhãn", type: "text", default: "" },
        ],
      },
    ],
    render: (p) => {
      const items = list(p.items);
      return `<section class="bg-indigo-600 text-white">
  <div class="max-w-6xl mx-auto px-6 py-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
    ${items
      .map(
        (it) => `<div>
      <div class="text-4xl md:text-5xl font-bold">${esc(it.value)}</div>
      <div class="text-indigo-200 text-sm mt-1">${esc(it.label)}</div>
    </div>`,
      )
      .join("")}
  </div>
</section>`;
    },
  },
  {
    key: "gallery",
    category: "Thư viện",
    label: "Thư viện ảnh",
    description: "Lưới 6 ảnh",
    icon: "Image",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Hình ảnh của chúng tôi" },
      {
        key: "items",
        label: "Ảnh",
        type: "list",
        default: JSON.stringify([
          { url: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600" },
          { url: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=600" },
          { url: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=600" },
          { url: "https://images.unsplash.com/photo-1521017432531-fbd92d768814?w=600" },
          { url: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=600" },
          { url: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600" },
        ]),
        itemFields: [{ key: "url", label: "URL ảnh", type: "image", default: "" }],
      },
    ],
    render: (p) => {
      const items = list(p.items);
      return `<section class="bg-white">
  <div class="max-w-6xl mx-auto px-6 py-20">
    <h2 class="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-14">${esc(p.title)}</h2>
    <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
      ${items.map((it) => `<img src="${esc(it.url)}" class="w-full h-56 object-cover rounded-xl" alt="" />`).join("")}
    </div>
  </div>
</section>`;
    },
  },
  {
    key: "faq",
    category: "FAQ",
    label: "Câu hỏi thường gặp",
    description: "Danh sách hỏi đáp",
    icon: "HelpCircle",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Câu hỏi thường gặp" },
      {
        key: "items",
        label: "Câu hỏi",
        type: "list",
        default: JSON.stringify([
          { q: "Mất bao lâu để hoàn thành?", a: "Thông thường từ 5-10 ngày làm việc tùy độ phức tạp." },
          { q: "Có hỗ trợ sau khi bàn giao không?", a: "Có, chúng tôi hỗ trợ miễn phí 6 tháng đầu." },
          { q: "Tôi cần chuẩn bị gì?", a: "Chỉ cần mô tả ý tưởng, mọi thứ còn lại chúng tôi lo." },
        ]),
        itemFields: [
          { key: "q", label: "Câu hỏi", type: "text", default: "" },
          { key: "a", label: "Trả lời", type: "textarea", default: "" },
        ],
      },
    ],
    render: (p) => {
      const items = list(p.items);
      return `<section class="bg-slate-50">
  <div class="max-w-3xl mx-auto px-6 py-20">
    <h2 class="text-3xl md:text-4xl font-bold text-slate-900 text-center mb-12">${esc(p.title)}</h2>
    <div class="space-y-3">
      ${items
        .map(
          (it) => `<details class="bg-white p-6 rounded-xl border border-slate-200 group">
        <summary class="font-semibold text-slate-900 cursor-pointer list-none flex justify-between items-center">
          <span>${esc(it.q)}</span><span class="text-2xl text-slate-400 group-open:rotate-45 transition">+</span>
        </summary>
        <p class="text-slate-600 mt-3">${esc(it.a)}</p>
      </details>`,
        )
        .join("")}
    </div>
  </div>
</section>`;
    },
  },
  {
    key: "cta",
    category: "Kêu gọi",
    label: "CTA banner",
    description: "Gọi hành động cuối trang",
    icon: "Megaphone",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Sẵn sàng bắt đầu?" },
      { key: "subtitle", label: "Phụ đề", type: "textarea", default: "Liên hệ ngay hôm nay để nhận tư vấn miễn phí." },
      { key: "buttonText", label: "Nút", type: "text", default: "Liên hệ ngay" },
    ],
    render: (p) => `<section class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
  <div class="max-w-4xl mx-auto px-6 py-20 text-center">
    <h2 class="text-3xl md:text-5xl font-bold mb-5">${esc(p.title)}</h2>
    <p class="text-lg text-indigo-100 mb-8">${esc(p.subtitle)}</p>
    <a href="#" class="inline-block bg-white text-indigo-700 px-8 py-3 rounded-full font-semibold hover:bg-indigo-50">${esc(p.buttonText)}</a>
  </div>
</section>`,
  },
  {
    key: "contact",
    category: "Liên hệ",
    label: "Form liên hệ",
    description: "Form + thông tin liên hệ",
    icon: "Mail",
    fields: [
      { key: "title", label: "Tiêu đề", type: "text", default: "Liên hệ với chúng tôi" },
      { key: "subtitle", label: "Mô tả", type: "textarea", default: "Để lại thông tin, chúng tôi sẽ liên hệ trong vòng 24 giờ." },
      { key: "phone", label: "Điện thoại", type: "text", default: "0901 234 567" },
      { key: "email", label: "Email", type: "text", default: "hello@example.vn" },
      { key: "address", label: "Địa chỉ", type: "text", default: "123 Nguyễn Huệ, Quận 1, TP.HCM" },
    ],
    render: (p) => `<section class="bg-white">
  <div class="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-12">
    <div>
      <h2 class="text-3xl md:text-4xl font-bold text-slate-900 mb-4">${esc(p.title)}</h2>
      <p class="text-slate-600 mb-8">${esc(p.subtitle)}</p>
      <div class="space-y-4 text-slate-700">
        <div class="flex gap-3"><span>📞</span><span>${esc(p.phone)}</span></div>
        <div class="flex gap-3"><span>✉️</span><span>${esc(p.email)}</span></div>
        <div class="flex gap-3"><span>📍</span><span>${esc(p.address)}</span></div>
      </div>
    </div>
    <form class="bg-slate-50 p-8 rounded-2xl space-y-4">
      <input type="text" placeholder="Họ và tên" class="w-full px-4 py-3 rounded-lg border border-slate-200 bg-white" />
      <input type="email" placeholder="Email" class="w-full px-4 py-3 rounded-lg border border-slate-200 bg-white" />
      <input type="tel" placeholder="Số điện thoại" class="w-full px-4 py-3 rounded-lg border border-slate-200 bg-white" />
      <textarea placeholder="Nội dung" rows="4" class="w-full px-4 py-3 rounded-lg border border-slate-200 bg-white"></textarea>
      <button type="button" class="bg-slate-900 text-white px-6 py-3 rounded-lg font-medium w-full">Gửi tin nhắn</button>
    </form>
  </div>
</section>`,
  },
  {
    key: "footer",
    category: "Cuối trang",
    label: "Footer",
    description: "Chân trang đơn giản",
    icon: "Square",
    fields: [
      { key: "brand", label: "Tên thương hiệu", type: "text", default: "Thương hiệu" },
      { key: "tagline", label: "Khẩu hiệu", type: "text", default: "Đồng hành cùng bạn từ 2015" },
      { key: "copyright", label: "Bản quyền", type: "text", default: "© 2026 Thương hiệu. All rights reserved." },
    ],
    render: (p) => `<footer class="bg-slate-900 text-slate-300">
  <div class="max-w-6xl mx-auto px-6 py-12 text-center">
    <div class="text-xl font-bold text-white mb-2">${esc(p.brand)}</div>
    <p class="text-slate-400 mb-6">${esc(p.tagline)}</p>
    <div class="text-sm text-slate-500 border-t border-slate-800 pt-6">${esc(p.copyright)}</div>
  </div>
</footer>`,
  },
];

export const MODULE_BY_KEY: Record<string, ModuleDef> = Object.fromEntries(
  MODULES.map((m) => [m.key, m]),
);

export interface BlockInstance {
  id: string;
  moduleKey: string;
  props: Record<string, unknown>;
}

export function defaultProps(mod: ModuleDef): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const f of mod.fields) {
    if (f.type === "list") {
      try {
        out[f.key] = JSON.parse(f.default);
      } catch {
        out[f.key] = [];
      }
    } else {
      out[f.key] = f.default;
    }
  }
  return out;
}

export function buildHtml(blocks: BlockInstance[], pageTitle: string): string {
  const body = blocks
    .map((b) => {
      const m = MODULE_BY_KEY[b.moduleKey];
      return m ? m.render(b.props) : "";
    })
    .join("\n");
  return `<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>${esc(pageTitle)}</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
<style>body{font-family:'Inter',system-ui,sans-serif;}</style>
</head>
<body class="bg-white">
${body}
</body>
</html>`;
}
