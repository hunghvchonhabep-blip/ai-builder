import { createContext, useContext, type ReactNode } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getGetMeQueryKey,
  useGetMe,
  useLogin,
  useLogout,
  useRegister,
  type Me,
} from "@workspace/api-client-react";

type AuthValue = {
  me: Me | null;
  isLoading: boolean;
  refetch: () => void;
};

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { data, isLoading, refetch } = useGetMe({
    query: { staleTime: 30_000 },
  });
  return (
    <AuthContext.Provider
      value={{
        me: data?.user ?? null,
        isLoading,
        refetch: () => void refetch(),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth outside provider");
  return ctx;
}

export function useLoginMutation() {
  const qc = useQueryClient();
  return useLogin({
    mutation: {
      onSuccess: (data) => {
        qc.setQueryData(getGetMeQueryKey(), { user: data });
        qc.invalidateQueries();
      },
    },
  });
}
export function useRegisterMutation() {
  const qc = useQueryClient();
  return useRegister({
    mutation: {
      onSuccess: (data) => {
        qc.setQueryData(getGetMeQueryKey(), { user: data });
        qc.invalidateQueries();
      },
    },
  });
}
export function useLogoutMutation() {
  const qc = useQueryClient();
  return useLogout({
    mutation: {
      onSuccess: () => {
        qc.setQueryData(getGetMeQueryKey(), { user: null });
        qc.invalidateQueries();
      },
    },
  });
}

// Re-export useQuery for convenience
export { useQuery, useMutation };
