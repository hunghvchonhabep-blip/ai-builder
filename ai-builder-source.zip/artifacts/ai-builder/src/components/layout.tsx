import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Sparkles,
  LayoutTemplate,
  Blocks,
  Coins,
  User as UserIcon,
  LogOut,
  ShieldCheck,
  Users,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth, useLogoutMutation } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { me } = useAuth();
  const logout = useLogoutMutation();

  const navItems = [
    { href: "/", label: "Tạo Website", icon: Sparkles },
    { href: "/builder", label: "Kéo thả", icon: Blocks },
    { href: "/sites", label: "Dự án của tôi", icon: LayoutDashboard },
    { href: "/templates", label: "Cảm hứng", icon: LayoutTemplate },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg text-primary tracking-tight">
            <Sparkles className="h-5 w-5" />
            <span>AI Builder</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary",
                  location === item.href ? "text-primary" : "text-muted-foreground",
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            {me ? (
              <>
                <Link href="/account/topup">
                  <Button variant="outline" size="sm" className="gap-1.5" data-testid="button-points">
                    <Coins className="h-4 w-4 text-yellow-500" />
                    <span className="font-semibold">{me.points}</span>
                    <span className="text-muted-foreground text-xs">điểm</span>
                  </Button>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-2" data-testid="button-user-menu">
                      <div className="h-7 w-7 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold">
                        {me.name.slice(0, 1).toUpperCase()}
                      </div>
                      <span className="hidden sm:inline text-sm">{me.name}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>
                      <div className="flex flex-col">
                        <span className="font-semibold">{me.name}</span>
                        <span className="text-xs text-muted-foreground font-normal">{me.email}</span>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setLocation("/account")}>
                      <UserIcon className="h-4 w-4 mr-2" /> Tài khoản & Lịch sử
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLocation("/account/topup")}>
                      <Coins className="h-4 w-4 mr-2" /> Nạp điểm
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLocation("/account/affiliate")}>
                      <Users className="h-4 w-4 mr-2" /> Cộng tác viên (CTV)
                    </DropdownMenuItem>
                    {me.role === "admin" && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setLocation("/admin")}>
                          <ShieldCheck className="h-4 w-4 mr-2" /> Trang quản trị
                        </DropdownMenuItem>
                      </>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => logout.mutate()}>
                      <LogOut className="h-4 w-4 mr-2" /> Đăng xuất
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="ghost" size="sm">Đăng nhập</Button>
                </Link>
                <Link href="/register">
                  <Button size="sm">Đăng ký</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>
      <main className="flex-1 flex flex-col">{children}</main>
    </div>
  );
}
