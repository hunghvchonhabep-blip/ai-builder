import { Link } from "wouter";
import { format } from "date-fns";
import { vi } from "date-fns/locale";
import { ExternalLink, MoreVertical, Trash, Edit3 } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import type { SiteSummary } from "@workspace/api-client-react";

interface SiteCardProps {
  site: SiteSummary;
  onDelete: (id: string) => void;
  isDeleting?: boolean;
}

export function SiteCard({ site, onDelete, isDeleting }: SiteCardProps) {
  return (
    <Card className="group overflow-hidden transition-all hover:shadow-md border-border/50 bg-card hover:border-primary/20 flex flex-col h-full">
      <CardHeader className="p-4 pb-0 flex-row items-start justify-between space-y-0">
        <div className="space-y-1 truncate pr-4">
          <Link href={`/sites/${site.id}`} className="font-semibold text-lg hover:text-primary transition-colors truncate block">
            {site.title || "Website chưa có tên"}
          </Link>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>Cập nhật {format(new Date(site.updatedAt), "dd MMM, yyyy", { locale: vi })}</span>
          </div>
        </div>
        <AlertDialog>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="-mr-2 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreVertical className="h-4 w-4" />
                <span className="sr-only">Menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <Link href={`/sites/${site.id}`}>
                <DropdownMenuItem className="cursor-pointer">
                  <Edit3 className="mr-2 h-4 w-4" /> Chỉnh sửa
                </DropdownMenuItem>
              </Link>
              <AlertDialogTrigger asChild>
                <DropdownMenuItem className="text-destructive cursor-pointer">
                  <Trash className="mr-2 h-4 w-4" /> Xóa
                </DropdownMenuItem>
              </AlertDialogTrigger>
            </DropdownMenuContent>
          </DropdownMenu>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Xóa dự án này?</AlertDialogTitle>
              <AlertDialogDescription>
                Hành động này không thể hoàn tác. Website sẽ bị xóa vĩnh viễn.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Hủy</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => onDelete(site.id)}
                disabled={isDeleting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Xóa
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardHeader>
      <CardContent className="p-4 flex-1">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {site.description || "Chưa có mô tả"}
        </p>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center mt-auto">
        {site.industry ? (
          <Badge variant="secondary" className="bg-secondary/50 font-normal">
            {site.industry}
          </Badge>
        ) : (
          <div />
        )}
        <Button variant="ghost" size="sm" className="h-8 gap-1" asChild>
          <Link href={`/sites/${site.id}`}>
            Mở <ExternalLink className="h-3 w-3 ml-1" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
