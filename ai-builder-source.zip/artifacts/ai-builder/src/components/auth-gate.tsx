import { Link } from "wouter";
import { Sparkles, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export function AuthGate({ children }: { children: React.ReactNode }) {
  const { me, isLoading } = useAuth();
  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        Đang tải...
      </div>
    );
  }
  if (!me) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-md w-full text-center space-y-4 border rounded-2xl p-8 bg-card">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary/10 text-primary">
            <Lock className="h-6 w-6" />
          </div>
          <h2 className="text-xl font-bold">Vui lòng đăng nhập</h2>
          <p className="text-sm text-muted-foreground">
            Bạn cần đăng nhập để sử dụng tính năng này.
          </p>
          <div className="flex gap-2 justify-center">
            <Link href="/login">
              <Button variant="outline">Đăng nhập</Button>
            </Link>
            <Link href="/register">
              <Button>
                <Sparkles className="h-4 w-4 mr-1" /> Đăng ký miễn phí
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}

export function AdminGate({ children }: { children: React.ReactNode }) {
  const { me, isLoading } = useAuth();
  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        Đang tải...
      </div>
    );
  }
  if (!me || me.role !== "admin") {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-md w-full text-center space-y-2 border rounded-2xl p-8 bg-card">
          <h2 className="text-xl font-bold">Khu vực dành cho quản trị viên</h2>
          <p className="text-sm text-muted-foreground">
            Bạn không có quyền truy cập trang này.
          </p>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}
