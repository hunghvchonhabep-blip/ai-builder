import { useState } from "react";
import { Link } from "wouter";
import { ArrowRight, Eye } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import type { Template } from "@workspace/api-client-react";

interface TemplateCardProps {
  template: Template;
}

export function TemplateCard({ template }: TemplateCardProps) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Card className="group overflow-hidden transition-all hover:shadow-lg border-border/50 hover:border-primary/50 flex flex-col h-full relative bg-card">
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="relative block w-full text-left aspect-[16/10] overflow-hidden bg-muted/40"
          aria-label={`Xem trước ${template.title}`}
        >
          <iframe
            srcDoc={template.previewHtml}
            title={`${template.title} preview`}
            className="absolute top-0 left-0 origin-top-left pointer-events-none"
            style={{
              width: "1280px",
              height: "800px",
              transform: "scale(0.32)",
              border: "0",
            }}
            sandbox="allow-scripts"
            scrolling="no"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/90 backdrop-blur px-3 py-1.5 text-xs font-semibold text-slate-900 shadow">
              <Eye className="h-3.5 w-3.5" /> Xem trước
            </span>
          </div>
        </button>
        <CardHeader className="p-5 pb-2">
          <Badge
            variant="outline"
            className="w-fit mb-3 bg-background/50 backdrop-blur-sm font-medium"
          >
            {template.industry}
          </Badge>
          <h3 className="font-bold text-xl tracking-tight text-foreground group-hover:text-primary transition-colors">
            {template.title}
          </h3>
        </CardHeader>
        <CardContent className="p-5 pt-2 flex-1">
          <p className="text-muted-foreground text-sm leading-relaxed">
            {template.description}
          </p>
        </CardContent>
        <CardFooter className="p-5 pt-0 mt-auto flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => setOpen(true)}
          >
            <Eye className="mr-2 h-4 w-4" /> Xem trước
          </Button>
          <Button className="flex-1" asChild>
            <Link href={`/?prompt=${encodeURIComponent(template.prompt)}`}>
              Dùng mẫu <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </CardFooter>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-6xl w-[95vw] h-[90vh] p-0 overflow-hidden flex flex-col">
          <DialogHeader className="px-6 py-4 border-b shrink-0">
            <div className="flex items-center justify-between gap-4">
              <div className="min-w-0">
                <DialogTitle className="flex items-center gap-2 text-lg">
                  <span className="text-2xl">{template.emoji}</span>
                  <span className="truncate">{template.title}</span>
                  <Badge variant="outline" className="ml-1 hidden sm:inline-flex">
                    {template.industry}
                  </Badge>
                </DialogTitle>
                <DialogDescription className="mt-1 truncate">
                  {template.description}
                </DialogDescription>
              </div>
              <Button asChild size="sm" className="shrink-0">
                <Link href={`/?prompt=${encodeURIComponent(template.prompt)}`}>
                  Dùng mẫu này <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </DialogHeader>
          <div className="flex-1 bg-muted/30 overflow-hidden">
            <iframe
              srcDoc={template.previewHtml}
              title={`${template.title} preview large`}
              className="w-full h-full border-0 bg-white"
              sandbox="allow-scripts"
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
